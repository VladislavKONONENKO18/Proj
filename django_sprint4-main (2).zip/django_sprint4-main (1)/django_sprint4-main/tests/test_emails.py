"""
Тесты для проверки конфигурации e-mail и наличия `.gitignore`.

Этот модуль включает тесты для проверки:
1. Наличия файла `.gitignore` и его корректного содержания.
2. Настройки бэкенда для отправки e-mail сообщений и корректного пути для хранения отправленных писем.
"""
from django.conf import settings
from django.core.mail.backends.locmem import EmailBackend


def test_gitignore():
    """
    Проверяет, что файл `.gitignore` существует в корне проекта и содержит
    указание на директорию `sent_emails/`.
    """
    try:
        with open(
                settings.BASE_DIR / ".." / ".gitignore",
                "r",
                encoding="utf-8",
                errors="ignore",
        ) as fh:
            gitignore = fh.read()
    except Exception as e:
        raise AssertionError(
            "При чтении файла `.gitignore` в корне проекта возникла ошибка:\n"
            f"{type(e).__name__}: {e}"
        )
    assert "sent_emails/" in gitignore, (
        "Убедитесь, что директория `sent_emails/`, служащая для хранения"
        " e-mail сообщений, указана в файле `.gitignore` в корне проекта."
    )


def test_email_backend_settings():
    """
    Проверяет, что:
    1. Настройка `EMAIL_BACKEND` задана.
    2. Подключен файловый бэкенд для отправки e-mail сообщений.
    3. Настройка `EMAIL_FILE_PATH` указывает на директорию `sent_emails/`.
    """
    # Проверяем наличие настройки EMAIL_BACKEND
    assert hasattr(
        settings, "EMAIL_BACKEND"
    ), "Убедитесь, что в проекте задана настройка `EMAIL_BACKEND`."

    # Проверяем подключение файлового бэкенда
    assert EmailBackend.__module__ in settings.EMAIL_BACKEND, (
        "Убедитесь, что файловый бэкенд для отправки e-mail подключен с"
        " помощью настройки `EMAIL_BACKEND`."
    )

    # Проверяем правильность пути для хранения писем
    expected_email_file = settings.BASE_DIR / "sent_emails"
    assert getattr(settings, "EMAIL_FILE_PATH", "") == expected_email_file, (
        "Убедитесь, что в настройке `EMAIL_FILE_PATH` указан путь `BASE_DIR /"
        " 'sent_emails'`."
    )
