"""
Фикстуры для категорий.

Этот модуль предоставляет фикстуры для создания опубликованных категорий
и дополнительных категорий с помощью библиотеки `mixer`.

Особенности:
- Использует `mixer` для генерации объектов модели.
- Упрощает создание тестовых данных для категорий блога.
"""

import pytest
from mixer.backend.django import Mixer


@pytest.fixture
def published_category(mixer: Mixer):
    """
    Создаёт опубликованную категорию.

    Возвращает:
        Category: Объект категории с флагом `is_published=True`.
    """
    return mixer.blend("blog.Category", is_published=True)


@pytest.fixture
def another_category(mixer: Mixer):
    """
    Создаёт ещё одну опубликованную категорию.

    Возвращает:
        Category: Объект категории с флагом `is_published=True`.
    """
    return mixer.blend("blog.Category", is_published=True)
