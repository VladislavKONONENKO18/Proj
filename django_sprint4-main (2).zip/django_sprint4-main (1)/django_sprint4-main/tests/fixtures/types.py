"""
Определение обобщённых типов для адаптеров моделей.

Этот файл содержит определения типов для использования с адаптерами моделей,
включая адаптеры постов, комментариев и пользователей.

Основные моменты:
- `CommentModelAdapterT`: Обобщённый тип для адаптера модели комментариев.
- `ModelAdapterT`: Универсальный тип, включающий адаптеры моделей комментариев,
  постов и пользователей.
"""

from typing import TypeVar, Union

from adapters.post import PostModelAdapter
from adapters.user import UserModelAdapter

# Обобщённый тип для адаптера модели комментариев
CommentModelAdapterT = TypeVar("CommentModelAdapterT", bound=type)

# Универсальный тип, объединяющий различные адаптеры моделей
ModelAdapterT = Union[CommentModelAdapterT, PostModelAdapter, UserModelAdapter]
