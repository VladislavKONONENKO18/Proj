"""
Фикстуры для комментариев.

Этот модуль предоставляет фикстуры для создания тестовых данных
модели комментариев с использованием библиотеки `mixer`.

Особенности:
- Создание базового комментария и комментария, привязанного к посту.
- Использует адаптер модели для обеспечения универсального доступа
  к атрибутам модели.
"""

from typing import Type

import pytest
from django.db.models import Model
from mixer.backend.django import Mixer

from fixtures.types import CommentModelAdapterT


@pytest.fixture
def comment(
    mixer: Mixer,
    user: object,
    CommentModel: type,
    CommentModelAdapter: CommentModelAdapterT,
) -> CommentModelAdapterT:
    """
    Создаёт базовый комментарий.

    Аргументы:
        mixer (Mixer): Инструмент для создания объектов моделей.
        user (object): Пользователь, связанный с комментарием.
        CommentModel (type): Класс модели комментария.
        CommentModelAdapter (CommentModelAdapterT): Адаптер для модели комментария.

    Возвращает:
        CommentModelAdapterT: Адаптированный объект комментария.
    """
    comment = mixer.blend(f"blog.{CommentModel.__name__}")
    adapted = CommentModelAdapter(comment)
    return adapted


@pytest.fixture
def comment_to_a_post(
    mixer: Mixer,
    post_with_published_location: Model,
    CommentModel: Type[Model],
    CommentModelAdapter: CommentModelAdapterT,
):
    """
    Создаёт комментарий, привязанный к опубликованному посту.

    Аргументы:
        mixer (Mixer): Инструмент для создания объектов моделей.
        post_with_published_location (Model): Опубликованный пост, к которому привязан комментарий.
        CommentModel (Type[Model]): Класс модели комментария.
        CommentModelAdapter (CommentModelAdapterT): Адаптер для модели комментария.

    Возвращает:
        Model: Объект комментария, связанный с указанным постом.
    """
    comment_model_name = CommentModel.__name__
    post_field_name = CommentModelAdapter(CommentModel).post.field.name
    mixer_kwargs = {post_field_name: post_with_published_location}
    return mixer.blend(f"blog.{comment_model_name}", **mixer_kwargs)
