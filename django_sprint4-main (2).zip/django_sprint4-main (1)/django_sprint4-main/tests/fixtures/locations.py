"""
Фикстуры для работы с локациями.

Этот модуль предоставляет фикстуры для создания тестовых данных
модели локаций с использованием библиотеки `mixer`.

Особенности:
- Создание нескольких локаций в опубликованном состоянии.
- Создание одной опубликованной локации.
"""

import pytest
from mixer.backend.django import Mixer

from conftest import N_PER_FIXTURE


@pytest.fixture
def published_locations(mixer: Mixer):
    """
    Создаёт несколько опубликованных локаций.

    Аргументы:
        mixer (Mixer): Инструмент для создания объектов моделей.

    Возвращает:
        list: Список опубликованных локаций.
    """
    return mixer.cycle(N_PER_FIXTURE).blend("blog.Location")


@pytest.fixture
def published_location(mixer: Mixer):
    """
    Создаёт одну опубликованную локацию.

    Аргументы:
        mixer (Mixer): Инструмент для создания объектов моделей.

    Возвращает:
        Model: Опубликованная локация.
    """
    return mixer.blend("blog.Location", is_published=True)
