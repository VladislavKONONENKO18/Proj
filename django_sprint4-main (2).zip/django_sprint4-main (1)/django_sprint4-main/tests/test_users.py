"""
Тестирование маршрутов и шаблонов для управления пользователями.

Этот тест проверяет:
1. Корректность подключения маршрутов из `django.contrib.auth.urls`.
2. Переопределение маршрута `auth/registration/`.
3. Наличие и корректность пути к шаблонам для всех стандартных страниц аутентификации и управления пользователями.
"""
@pytest.mark.django_db
def test_custom_err_handlers(client):
    # Проверка подключения маршрутов `django.contrib.auth.urls`
    try:
        from blogicum import urls as blogicum_urls
    except Exception:
        raise AssertionError(
            "Убедитесь, в головном файле с маршрутами нет ошибок."
        )

    urls_src_squashed = squash_code(inspect.getsource(blogicum_urls))
    if "django.contrib.auth.urls" not in urls_src_squashed:
        raise AssertionError(
            "Убедитесь, что подключены маршруты для работы с пользователями из"
            " `django.contrib.auth.urls`."
        )

    # Поиск маршрута `auth/registration/`
    def search_url_patterns(substring):
        resolver = get_resolver()
        results = []

        def search_patterns(head, patterns):
            for pattern in patterns:
                if isinstance(pattern, URLPattern):
                    pattern_as_str = head + str(pattern.pattern)
                    if substring in pattern_as_str:
                        results.append(pattern)
                elif isinstance(pattern, URLResolver):
                    search_patterns(
                        head + str(pattern.pattern), pattern.url_patterns
                    )
            return results

        search_patterns(head="", patterns=resolver.url_patterns)
        return results

    registration_url = "auth/registration/"
    auth_registration_patterns = search_url_patterns(registration_url)
    assert auth_registration_patterns, (
        "Убедитесь, что в головном файле с маршрутами переопределён маршрут"
        f" `{registration_url}`."
    )

    # Проверка наличия шаблонов для страниц аутентификации
    auth_templates = {
        "logged_out.html",
        "login.html",
        "password_change_done.html",
        "password_change_form.html",
        "password_reset_complete.html",
        "password_reset_confirm.html",
        "password_reset_done.html",
        "password_reset_form.html",
        "registration_form.html",
    }

    for template in auth_templates:
        try:
            fpath: Path = Path(settings.TEMPLATES_DIR) / "registration" / template
        except Exception as e:
            raise AssertionError(
                'Убедитесь, что переменная TEMPLATES_DIR в настройках проекта '
                'является строкой (str) или объектом, соответствующим path-like интерфейсу '
                '(например, экземпляром pathlib.Path). '
                f'При операции Path(settings.TEMPLATES_DIR) / "registration", возникла ошибка: {e}'
            )
        frpath: Path = fpath.relative_to(settings.BASE_DIR)
        assert os.path.isfile(
            fpath.resolve()
        ), f"Убедитесь, что файл шаблона `{frpath}` существует."
@pytest.mark.django_db
def test_profile(
        user, another_user, user_client, another_user_client, unlogged_client
):
    # URL профиля текущего пользователя
    user_url = f"/profile/{user.username}/"
    printed_url = "/profile/<username>/"

    # Проверка, что запрос на профиль несуществующего пользователя возвращает 404
    User = get_user_model()
    status_code_not_404_err_msg = (
        "Убедитесь, что при обращении к странице несуществующего "
        "пользователя возвращается статус 404."
    )
    try:
        response = user_client.get("/profile/this_is_unexisting_user_name/")
    except User.DoesNotExist:
        raise AssertionError(status_code_not_404_err_msg)

    assert response.status_code == HTTPStatus.NOT_FOUND, status_code_not_404_err_msg

    # Получение контента страницы профиля для разных пользователей
    user_response: HttpResponse = user_client.get(user_url)
    user_content = user_response.content.decode("utf-8")

    anothers_same_page_response: HttpResponse = another_user_client.get(user_url)
    anothers_same_page_content = anothers_same_page_response.content.decode("utf-8")

    unlogged_same_page_response: HttpResponse = unlogged_client.get(user_url)
    unlogged_same_page_content = unlogged_same_page_response.content.decode("utf-8")

    # Проверка отображения информации о пользователе
    for profile_user, profile_user_content in (
            (user, user_content),
            (user, unlogged_same_page_content),
            (user, anothers_same_page_content),
    ):
        _test_user_info_displayed(profile_user, profile_user_content, printed_url)

    # Проверка доступности ссылок редактирования профиля
    try:
        edit_url, change_pwd_url = try_get_profile_manage_urls(
            user_content, anothers_same_page_content, ignore_urls={user_url}
        )
    except ManageProfileLinksException:
        raise AssertionError(
            "Убедитесь, что на странице профиля пользователя ссылки для"
            " редактирования профиля и изменения пароля видны только владельцу"
            " профиля, но не другим пользователям."
        )

    # Проверка, что неаутентифицированному пользователю недоступны ссылки на управление профилем
    unlogged_diff_urls = get_extra_urls(
        base_content=unlogged_same_page_content, extra_content=user_content
    )

    assert {edit_url, change_pwd_url}.issubset(set(unlogged_diff_urls)), (
        "Убедитесь, что неаутентифицированному пользователю недоступны ссылки"
        " для редактирования профиля и изменения пароля."
    )

    # Тест редактирования профиля
    item_to_edit = user
    item_to_edit_adapter = UserModelAdapter(item_to_edit)
    old_prop_value = item_to_edit_adapter.displayed_field_name_or_value
    update_props = {
        item_to_edit_adapter.item_cls_adapter.displayed_field_name_or_value: (
            f"{old_prop_value} edited"
        )
    }
    _test_edit(
        KeyVal(edit_url, edit_url),
        UserModelAdapter,
        user,
        EditFormTester=EditUserFormTester,
        user_client=user_client,
        unlogged_client=unlogged_client,
        **update_props,
    )


def _test_user_info_displayed(
        profile_user: Model, profile_user_content: str, printed_url: str
) -> None:
    """
    Проверяет, отображается ли информация о пользователе на странице профиля.
    """
    if profile_user.first_name not in profile_user_content:
        raise AssertionError(
            f"Убедитесь, что на странице `{printed_url}` отображается имя"
            " пользователя."
        )
    if profile_user.last_name not in profile_user_content:
        raise AssertionError(
            f"Убедитесь, что на странице `{printed_url}` отображается фамилия"
            " пользователя."
        )

def try_get_profile_manage_urls(
        user_content: str, anothers_page_content: str, ignore_urls: Set[str]
) -> Tuple[str, str]:
    """
    Находит и возвращает ссылки для редактирования профиля и изменения пароля на странице профиля.

    :param user_content: HTML-контент страницы профиля текущего пользователя.
    :param anothers_page_content: HTML-контент страницы профиля, видимой другому пользователю.
    :param ignore_urls: Набор URL, которые нужно игнорировать.
    :return: Кортеж из двух строк: URL для редактирования профиля и URL для изменения пароля.
    :raises ManageProfileLinksException: Если число найденных различий в URL не равно двум.
    """
    # Получение различий в ссылках между страницей пользователя и другой страницы
    diff_urls = get_extra_urls(
        base_content=anothers_page_content,
        extra_content=user_content,
        ignore_urls=ignore_urls,
    )
    if len(diff_urls) != 2:
        raise ManageProfileLinksException

    # Определение и проверка ссылок
    edit_url, change_pwd_url = diff_urls
    change_pwd_marker = "/auth/password_change/"
    if change_pwd_marker in edit_url:
        edit_url, change_pwd_url = change_pwd_url, edit_url
    if change_pwd_marker not in change_pwd_url:
        raise AssertionError(
            "Убедитесь, что на странице профиля владельцу этого профиля"
            f" доступна ссылка `{change_pwd_marker}` для изменения пароля."
        )

    return edit_url, change_pwd_url


def get_extra_urls(
        base_content: str,
        extra_content: str,
        ignore_urls: Optional[Set[str]] = None,
):
    """
    Находит ссылки, присутствующие в одном HTML-контенте, но отсутствующие в другом.

    :param base_content: HTML-контент базовой страницы.
    :param extra_content: HTML-контент страницы с дополнительными ссылками.
    :param ignore_urls: Набор URL, которые нужно игнорировать.
    :return: Список дополнительных ссылок.
    """
    ignore_urls = ignore_urls or set()
    find_links_kwargs = dict(
        urls_start_with="", start_lineix=-1, end_lineix=-1
    )
    # Найти ссылки в HTML-контенте
    user_links = set(
        find_links_between_lines(extra_content, **find_links_kwargs)
    )
    anothers_page_links = set(
        find_links_between_lines(base_content, **find_links_kwargs)
    )
    # Вычислить разницу и исключить игнорируемые ссылки
    diff_urls = [
        x.get("href")
        for x in (user_links - anothers_page_links)
        if x.get("href") not in ignore_urls
    ]
    return diff_urls
