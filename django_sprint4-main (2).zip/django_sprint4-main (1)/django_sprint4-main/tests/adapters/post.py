"""
Адаптер для модели Post.

Этот модуль предоставляет класс адаптера (`PostModelAdapter`) для работы с моделью
`Post`, используемой в проекте. Адаптер упрощает доступ к полям модели,
обеспечивает структурированное взаимодействие в тестах и поддерживает гибкость
при использовании различных реализаций модели.

Особенности:
- Обеспечивает доступ к полям модели на уровне класса и экземпляра.
- Абстрагирует взаимодействие с полями модели, такими как `image` и `title`.
- Содержит описания полей для обеспечения единообразия при тестировании и использовании.

Основные моменты:
- Метод `displayed_field_name_or_value` определяет, как обращаться к полю `title`,
  в зависимости от того, адаптер оборачивает класс или экземпляр.
"""

from inspect import isclass
from typing import Type

from django.db import models
from django.db.models import Model

from adapters.student_adapter import StudentModelAdapter


class PostModelAdapter(StudentModelAdapter):
    """
    Адаптер для модели `Post`, обеспечивающий структурированный доступ к полям.

    Пример использования:
    - На уровне класса:
        ```python
        class_adapter = PostModelAdapter(Post)
        print(class_adapter.image)  # Доступ к полю ImageField модели Post
        ```

    - На уровне экземпляра:
        ```python
        item_adapter = PostModelAdapter(Post())
        print(item_adapter.image)  # Доступ к полю ImageField экземпляра Post
        ```
    """

    @property
    def _access_by_name_fields(self):
        """
        Определяет поля, доступные по имени через адаптер.

        Возвращает:
            list[str]: Список имен полей, доступных для прямого доступа.
        """
        return [
            "id",
            "created_at",
            "is_published",
            "title",
            "text",
            "pub_date",
            "author",
            "category",
            "location",
            "refresh_from_db",
        ]

    @property
    def AdapterFields(self) -> type:
        """
        Определяет дополнительные поля, адаптируемые для модели `Post`.

        Возвращает:
            type: Класс, описывающий дополнительные поля и их назначения.
        """
        class _AdapterFields:
            image = models.ImageField()

            field_description = {
                "image": "служит для хранения изображения публикации",
            }

        return _AdapterFields

    @property
    def ItemModel(self) -> Type[Model]:
        """
        Возвращает класс модели `Post`.

        Возвращает:
            Type[Model]: Класс модели `Post`.
        """
        from blog.models import Post

        return Post

    @property
    def displayed_field_name_or_value(self):
        """
        Возвращает имя отображаемого поля или его значение.

        Для модели `Post` используется поле `title`. Значение очищается от
        символов перевода строки, если доступ осуществляется через экземпляр.

        Возвращает:
            str: Имя отображаемого поля или его значение.
        """
        if isclass(self._item_or_cls):
            return "title"
        else:
            return self.title.replace("\n", "")
