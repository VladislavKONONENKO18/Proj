"""
Адаптер для работы с моделями Django.

Этот модуль предоставляет базовый класс адаптера (`ModelAdapter`), который оборачивает
модель Django или её экземпляр. Адаптер обеспечивает унифицированный доступ к полям,
вне зависимости от реализации модели. Этот подход особенно полезен при тестировании
или работе с моделями, структура которых может быть заранее неизвестна.

Основные возможности:
- Упрощённый доступ к полям модели по имени.
- Поддержка как классов моделей, так и их экземпляров.
- Предоставление интерфейсов для адаптации в дочерних классах.

Особенности реализации:
- Свойство `displayed_field_name_or_value` абстрактное и должно быть реализовано
  в дочерних классах. Оно определяет, как поле отображается на странице.
- Свойства `item_cls` и `item_cls_adapter` обеспечивают доступ к классу модели
  или его адаптеру.
"""

from abc import abstractmethod, ABC
from inspect import isclass
from typing import Union, Type, Any

from django.db.models import Model


class ModelAdapter(ABC):
    """
    Базовый класс адаптера для модели или экземпляра модели Django.

    Использование:
    - Адаптеры, унаследованные от этого класса, должны реализовывать метод
      `displayed_field_name_or_value`.
    - Поддерживает работу как с классами моделей, так и с их экземплярами.
    """

    def __init__(self, item_or_class: Union[Model, Type[Model]]):
        """
        Инициализирует адаптер для переданного объекта.

        Параметры:
            item_or_class (Union[Model, Type[Model]]): Класс модели или её экземпляр.
        """
        self._item_or_cls = item_or_class

    def __getattr__(self, name: str) -> Any:
        """
        Обеспечивает доступ к атрибутам объекта, обёрнутого адаптером.

        Параметры:
            name (str): Имя атрибута.

        Возвращает:
            Any: Значение атрибута.
        """
        return getattr(self._item_or_cls, name)

    def get_student_field_name(self, field_name: str) -> str:
        """
        Возвращает имя поля студента, связанного с данным адаптером.

        Параметры:
            field_name (str): Имя поля.

        Возвращает:
            str: Имя поля в оригинальной модели.
        """
        return getattr(self.item_cls_adapter, field_name).field.name

    @property
    @abstractmethod
    def displayed_field_name_or_value(self):
        """
        Абстрактное свойство, возвращающее имя поля (для класса)
        или его значение (для экземпляра), отображаемое на странице.

        Должно быть реализовано в дочерних классах.
        """
        ...

    @property
    def item_cls(self):
        """
        Возвращает класс модели, связанный с адаптером.

        Возвращает:
            Type[Model]: Класс модели.
        """
        if isclass(self._item_or_cls):
            return self._item_or_cls
        else:
            return self._item_or_cls.__class__

    @property
    def item_cls_adapter(self):
        """
        Возвращает адаптер для класса модели.

        Возвращает:
            ModelAdapter: Адаптер для класса модели.
        """
        if isclass(self._item_or_cls):
            return self
        else:
            return self.__class__(self._item_or_cls.__class__)
