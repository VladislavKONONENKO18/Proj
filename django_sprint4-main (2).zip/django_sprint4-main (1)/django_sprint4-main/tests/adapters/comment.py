"""
Фабрика для адаптера модели комментариев.

- Этот модуль предоставляет адаптер для работы с моделью комментариев, что упрощает доступ к её полям.
- Реализует динамическую проверку полей модели на основе заданных требований.
- Содержит описание каждого поля модели и его назначения для удобства тестирования и расширения.

Особенности:
- Проверка ожидаемых полей модели на существование.
- Интеграция с `StudentModelAdapter` для наследования стандартных методов.
- Расширенные комментарии для удобства использования адаптера в автотестах.
"""

from inspect import isclass
from typing import Type

import pytest
from django.contrib.auth import get_user_model
from django.db import models
from django.db.models import Model

from adapters.student_adapter import StudentModelAdapter
from blog.models import Post
from conftest import COMMENT_TEXT_DISPLAY_LEN_FOR_TESTS
from fixtures.types import CommentModelAdapterT


@pytest.fixture
def CommentModelAdapter(CommentModel: type) -> CommentModelAdapterT:
    """
    Фабричная функция для создания адаптера модели комментариев.

    Args:
        CommentModel (type): Класс модели комментариев.

    Returns:
        CommentModelAdapterT: Адаптер для модели комментариев.
    """

    class _CommentModelAdapter(StudentModelAdapter):
        """
        Адаптер для модели комментариев.

        Пример использования:
        - С классом:
            class_adapter = ModelAdapter(CommentModel)
            class_adapter.text  # доступ к полю TextField класса CommentModel

        - С экземпляром:
            item_adapter = ModelAdapter(CommentModel())
            item_adapter.text  # доступ к полю TextField экземпляра CommentModel
        """

        @property
        def _access_by_name_fields(self):
            """
            Поля, доступ к которым осуществляется по имени.
            """
            return ["id", "refresh_from_db"]

        @property
        def AdapterFields(self) -> type:
            """
            Определение полей модели комментария.

            Returns:
                type: Вложенный класс, описывающий поля модели.
            """
            User = get_user_model()

            class _AdapterFields:
                post = models.ForeignKey(Post, on_delete=models.CASCADE)
                author = models.ForeignKey(User, on_delete=models.CASCADE)
                text = models.TextField()
                created_at = models.DateTimeField()

                field_description = {
                    "post": (
                        "Связывает модель `blog.models.Comment` "
                        "с моделью `blog.models.Post`."
                    ),
                    "author": (
                        "Указывает автора комментария, "
                        "связывая модель `blog.models.Comment` "
                        "с моделью `blog.models.User`."
                    ),
                    "text": "Определяет текст комментария.",
                    "created_at": "Сохраняет дату и время комментария.",
                }

            return _AdapterFields

        @property
        def ItemModel(self) -> Type[Model]:
            """
            Возвращает класс модели, для которой создан адаптер.
            """
            return CommentModel

        @property
        def displayed_field_name_or_value(self):
            """
            Возвращает имя отображаемого поля или значение для отображения.
            """
            if isclass(self._item_or_cls):
                return "text"
            else:
                return self.text.split("\n")[0][
                    :COMMENT_TEXT_DISPLAY_LEN_FOR_TESTS
                ]

    # Проверка существования ожидаемых полей в модели
    _comment_model_cls_adapter = _CommentModelAdapter(CommentModel)
    fields = {"text", "post", "author", "created_at"}
    for field in fields:
        getattr(_comment_model_cls_adapter, field)

    return _CommentModelAdapter
