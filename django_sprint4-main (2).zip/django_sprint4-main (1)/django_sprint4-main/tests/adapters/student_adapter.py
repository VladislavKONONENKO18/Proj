"""
Адаптер для модели студента.

Этот модуль реализует `StudentModelAdapter`, который наследуется от базового
`ModelAdapter` и предоставляет функциональность для работы с моделями,
структура которых может меняться или быть неизвестной.

Особенности:
- Динамическое определение полей модели на основе их типов.
- Упрощённый доступ к полям через интерфейс адаптера.
- Проверка соответствия структуры модели заданным спецификациям.
- Обеспечение корректной работы с атрибутами, не предназначенными для прямого
  доступа.

Основное применение:
Используется для проверки и тестирования моделей студентов в учебных проектах
или подобных сценариях.
"""

from abc import abstractmethod
from typing import Union, Type, Any

from django.db.models import Model, Field

from adapters.model_adapter import ModelAdapter
from conftest import get_field_key


class StudentModelAdapter(ModelAdapter):
    """
    Адаптер для работы с моделью студента. Наследуется от `ModelAdapter`.

    Основное назначение — унифицировать доступ к полям модели,
    проверять корректность их реализации и предоставлять дополнительные
    методы для работы с данными.
    """

    def __init__(self, item_or_class: Union[Model, Type[Model]]):
        """
        Инициализирует адаптер для переданной модели.

        Параметры:
            item_or_class (Union[Model, Type[Model]]): Класс модели или её экземпляр.
        """
        super().__init__(item_or_class=item_or_class)

    @property
    @abstractmethod
    def _access_by_name_fields(self):
        """
        Список имён полей, доступных напрямую.
        Должен быть определён в дочерних классах.
        """
        ...

    @property
    @abstractmethod
    def AdapterFields(self) -> type:
        """
        Описание полей адаптера, определяющее ожидаемую структуру модели.
        Должен быть определён в дочерних классах.
        """
        ...

    @property
    @abstractmethod
    def ItemModel(self) -> Type[Model]:
        """
        Класс модели, с которой работает адаптер.
        Должен быть определён в дочерних классах.
        """
        ...

    def __getattr__(self, name: str) -> Any:
        """
        Переопределяет доступ к атрибутам модели.

        Параметры:
            name (str): Имя атрибута.

        Возвращает:
            Any: Значение атрибута.

        Исключения:
            AssertionError: Если в модели отсутствует поле с указанным именем
            или его тип не соответствует ожидаемому.
        """
        if name.startswith("_") or name in self._access_by_name_fields:
            return getattr(self._item_or_cls, name)

        item_fields = [
            (f.name, type(f), getattr(self.ItemModel, f.name).field)
            for f in self.ItemModel._meta.concrete_fields
            if issubclass(type(f), Field)
            and (f.name not in self._access_by_name_fields)
        ]

        item_field_names = {
            get_field_key(_type, field): name
            for name, _type, field in item_fields
        }

        assert len(item_field_names) == len(item_fields), (
            f"Убедитесь, что в модели {self.ItemModel.__name__} нет полей,"
            " которые не описаны в задании. Проверьте, что для всех полей"
            " модели правильно заданы типы."
        )

        adapter_field_key = get_field_key(
            type(getattr(self.AdapterFields, name)),
            getattr(self.AdapterFields, name),
        )
        try:
            item_field_name = item_field_names[adapter_field_key]
        except KeyError:
            raise AssertionError(
                f"В модели `{self.ItemModel.__name__}` создайте поле типа"
                f" `{adapter_field_key[0]}`, которое"
                f" {self.AdapterFields.field_description[name]}."
            )
        return getattr(self._item_or_cls, item_field_name)

    def __setattr__(self, key, value):
        """
        Переопределяет установку атрибутов, чтобы учитывать соответствие полей модели.

        Параметры:
            key (str): Имя атрибута.
            value (Any): Значение атрибута.
        """
        if key.startswith("_"):
            self.__dict__[key] = value
            return
        student_key = self.get_student_field_name(key)
        setattr(self._item_or_cls, student_key, value)

    def save(self, *args, **kwargs):
        """
        Сохраняет изменения в экземпляре модели.
        """
        self._item_or_cls.save(*args, **kwargs)

    @property
    @abstractmethod
    def displayed_field_name_or_value(self):
        """
        Возвращает имя отображаемого поля (для класса) или его значение (для экземпляра).

        Должен быть реализован в дочерних классах.
        """
        ...
