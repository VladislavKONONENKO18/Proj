"""
Тестирование функциональности редактирования модели.

Данный модуль включает метод `_test_edit` для проверки возможности редактирования объектов
с использованием формы редактирования. Он обеспечивает проверку доступности формы,
правильности изменений и обработки ошибок для разных типов пользователей.
"""

from typing import Type, Optional, Dict

import django.test
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db.models import Model
from django.forms import BaseForm
from django.http import HttpResponse

from fixtures.types import ModelAdapterT
from form.base_form_tester import BaseFormTester
from conftest import (
    KeyVal,
    get_get_response_safely,
    _testget_context_item_by_class,
)


def _test_edit(
    edit_url_vs_printed_url: KeyVal,
    ModelAdapter: ModelAdapterT,
    item: Model,
    EditFormTester: Type[BaseFormTester],
    user_client: django.test.Client,
    another_user_client: Optional[django.test.Client] = None,
    unlogged_client: Optional[django.test.Client] = None,
    file_data: Optional[Dict[str, SimpleUploadedFile]] = None,
    **update_props
) -> HttpResponse:
    """
    Функция для тестирования редактирования объекта через форму.

    Параметры:
    - edit_url_vs_printed_url: KeyVal с URL редактирования и его представлением.
    - ModelAdapter: адаптер для работы с моделью.
    - item: объект модели, который нужно редактировать.
    - EditFormTester: тестировщик формы редактирования.
    - user_client: клиент аутентифицированного пользователя.
    - another_user_client: клиент другого аутентифицированного пользователя.
    - unlogged_client: клиент неаутентифицированного пользователя.
    - file_data: файлы, передаваемые в форму.
    - update_props: свойства для обновления объекта.
    """
    edit_url = edit_url_vs_printed_url.key
    item_adapter = ModelAdapter(item)
    ItemModel = type(item)

    def create_updated_form(**updated_props):
        """
        Создает обновленную форму с переданными значениями.

        Параметры:
        - updated_props: свойства, которые нужно обновить в форме.

        Возвращает:
        - Объект формы, готовой для отправки.
        """
        response = user_client.get(edit_url)
        _, form = _testget_context_item_by_class(
            response.context, BaseForm, ""
        )
        return EditFormTester.init_create_form_from_item(
            item,
            form.__class__,
            ModelAdapter=ModelAdapter,
            file_data=file_data,
            **updated_props
        )

    # Создаем форму с обновленными данными
    updated_form = create_updated_form(**update_props)

    # Проверяем доступность URL редактирования
    response = get_get_response_safely(user_client, edit_url)

    # Инициализируем тестировщик формы редактирования
    tester = EditFormTester(
        response,
        ItemModel,
        user_client,
        another_user_client,
        unlogged_client,
        ModelAdapter=ModelAdapter,
        item_adapter=item_adapter,
    )

    # Тестируем процесс редактирования объекта
    return tester.test_edit_item(
        updated_form, qs=ItemModel.objects.all(), item_adapter=item_adapter
    )
