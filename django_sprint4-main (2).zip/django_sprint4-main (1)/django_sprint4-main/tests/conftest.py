# Конфигурация и фикстуры для тестирования Django-приложений

import os
import re
import time
from http import HTTPStatus
from inspect import getsource
from pathlib import Path
from typing import (
    Iterable,
    Type,
    Optional,
    Union,
    Any,
    Tuple,
    List,
    NamedTuple,
    TypeVar,
)

import pytest
from django.apps import apps
from django.contrib.auth import get_user_model
from django.db.models import Model, Field
from django.forms import BaseForm
from django.http import HttpResponse
from django.test import override_settings
from django.test.client import Client
from mixer.backend.django import mixer as _mixer

# Константы для использования в тестах
N_PER_FIXTURE = 3  # Количество записей, создаваемых одной фикстурой
N_PER_PAGE = 10  # Количество записей на странице
COMMENT_TEXT_DISPLAY_LEN_FOR_TESTS = 50  # Ограничение длины текста комментариев

# Типы данных для удобства работы с URL
KeyVal = NamedTuple("KeyVal", [("key", Optional[str]), ("val", Optional[str])])
UrlRepr = NamedTuple("UrlRepr", [("url", str), ("repr", str)])
TitledUrlRepr = TypeVar("TitledUrlRepr", bound=Tuple[UrlRepr, str])

# Фикстура для включения режима `DEBUG=False`
@pytest.fixture(autouse=True)
def enable_debug_false():
    """
    Устанавливает значение DEBUG=False на время выполнения тестов.
    """
    with override_settings(DEBUG=False):
        yield

# Контекстный менеджер для безопасного импорта
class SafeImportFromContextManager:
    def __init__(
            self,
            import_path: str,
            import_names: Iterable[str],
            import_of: str = "",
    ):
        self._import_path: str = import_path
        self._import_names: Iterable[str] = import_names
        self._import_of = f"{import_of} " if import_of else ""

    def __enter__(self):
        pass

    def __exit__(self, exc_type, exc_value, traceback):
        """
        Проверяет на наличие ошибок при импорте модулей.
        """
        if exc_type is ImportError:
            disp_imp_names = "`, ".join(self._import_names)
            raise AssertionError(
                f"Убедитесь, что в файле `{self._import_path}` нет ошибок. "
                f"При импорте из него {self._import_of}"
                f"`{disp_imp_names}` возникла ошибка:\n"
                f"{exc_type.__name__}: {exc_value}"
            )

# Импортируем модели приложения `blog` с проверкой наличия ошибок
with SafeImportFromContextManager(
        "blog/models.py", ["Category", "Location", "Post"], import_of="моделей"
):
    try:
        from blog.models import Category, Location, Post  # noqa:F401
    except RuntimeError:
        registered_apps = set(app.name for app in apps.get_app_configs())
        need_apps = {"blog": "blog", "pages": "pages"}
        if not set(need_apps.values()).intersection(registered_apps):
            need_apps = {
                "blog": "blog.apps.BlogConfig",
                "pages": "pages.apps.PagesConfig",
            }

        for need_app_name, need_app_conf_name in need_apps.items():
            if need_app_conf_name not in registered_apps:
                raise AssertionError(
                    "Убедитесь, что зарегистрировано приложение "
                    f"{need_app_name}"
                )

# Подключаем плагины Pytest для работы с фикстурами
pytest_plugins = [
    "fixtures.posts",
    "fixtures.locations",
    "fixtures.categories",
    "fixtures.comments",
    "adapters.comment",
]

# Фикстура для работы с библиотекой Mixer
@pytest.fixture
def mixer():
    """
    Возвращает экземпляр Mixer для упрощенного создания тестовых данных.
    """
    return _mixer

# Фикстуры для создания пользователей
@pytest.fixture
def user(mixer):
    """
    Создает и возвращает пользователя.
    """
    User = get_user_model()
    user = mixer.blend(User)
    return user

@pytest.fixture
def another_user(mixer):
    """
    Создает и возвращает другого пользователя.
    """
    User = get_user_model()
    return mixer.blend(User)

# Фикстура для создания клиента с авторизованным пользователем
@pytest.fixture
def user_client(user):
    """
    Создает клиент с авторизованным пользователем.
    """
    client = Client()
    client.force_login(user)
    return client

@pytest.fixture
def unlogged_client(client):
    """
    Возвращает клиент без авторизации.
    """
    return client


@pytest.fixture
def another_user_client(another_user):
    """
    Возвращает клиент, авторизованный под другим пользователем.
    """
    client = Client()
    client.force_login(another_user)
    return client


def get_post_list_context_key(
    user_client, page_url, page_load_err_msg, key_missing_msg
):
    """
    Возвращает ключ контекста для списка постов на указанной странице.

    :param user_client: Клиент с авторизацией.
    :param page_url: URL страницы.
    :param page_load_err_msg: Сообщение об ошибке загрузки страницы.
    :param key_missing_msg: Сообщение об отсутствии ключа.
    """
    try:
        post_response = user_client.get(page_url)
    except Exception:
        raise AssertionError(page_load_err_msg)
    assert post_response.status_code == HTTPStatus.OK, page_load_err_msg
    post_list_key = None
    for key, val in dict(post_response.context).items():
        try:
            assert isinstance(iter(val).__next__(), Post)
            post_list_key = key
            break
        except Exception:
            pass
    assert post_list_key, key_missing_msg
    return post_list_key


class _TestModelAttrs:
    """
    Класс для проверки атрибутов моделей.
    """
    @property
    def model(self):
        """
        Абстрактное свойство, определяющее проверяемую модель.
        """
        raise NotImplementedError(
            "Override this property in inherited test class"
        )

    def get_parameter_display_name(self, param: str) -> str:
        """
        Возвращает отображаемое имя параметра.
        """
        return param

    def test_model_attrs(
        self, field: str, type: type, params: dict,
        field_error: Optional[str], type_error: Optional[str],
        param_error: Optional[str], value_error: Optional[str]
    ):
        """
        Проверяет, что поле модели соответствует указанным параметрам.

        :param field: Название поля.
        :param type: Тип поля.
        :param params: Словарь параметров и их значений.
        """
        model_name = self.model.__name__
        field_error = field_error or (
            f"В модели `{model_name}` укажите атрибут `{field}`."
        )
        assert hasattr(self.model, field), field_error

        model_field = getattr(self.model, field).field
        type_error = type_error or (
            f"В модели `{model_name}` у атрибута `{field}` "
            f"укажите тип `{type}`."
        )
        assert isinstance(model_field, type), type_error

        for param, value_param in params.items():
            display_name = self.get_parameter_display_name(param)
            param_error = param_error or (
                f"В модели `{model_name}` для атрибута `{field}` "
                f"укажите параметр `{display_name}`."
            )
            assert param in model_field.__dict__, param_error

            value_error = value_error or (
                f"В модели `{model_name}` в атрибуте `{field}` "
                f"проверьте значение параметра `{display_name}` "
                "на соответствие заданию."
            )
            assert model_field.__dict__.get(param) == value_param, value_error


@pytest.fixture
def PostModel() -> Type[Model]:
    """
    Возвращает модель `Post` или вызывает ошибку, если импорт не удался.
    """
    try:
        from blog.models import Post
    except Exception as e:
        raise AssertionError(
            "При импорте модели `Post` из файла `models.py` возникла ошибка."
            " Убедитесь, что в файле `blog/models.py` нет ошибок и что в нём"
            " объявлена модель Post. Сообщение об"
            f" ошибке:\n{type(e).__name__}: {e}"
        )
    return Post


@pytest.fixture
def CommentModel() -> Model:
    """
    Возвращает модель комментария или вызывает ошибку, если она отсутствует.
    """
    try:
        from blog import models
    except Exception as e:
        raise AssertionError(
            "Убедитесь, что в файле `blog/models.py` нет ошибок. "
            "При импорте `models.py` возникла ошибка:\n"
            f"{type(e).__name__}: {e}"
        )
    models_src_code = getsource(models)
    models_src_clean = re.sub("#.+", "", models_src_code)
    class_defs = re.findall(
        r"(class +\w+[\w\W]+?)(?=class)", models_src_clean + "class"
    )
    comment_class_name = ""
    known_class_names = {"BaseModel", "Meta", "Category", "Location", "Post"}
    for class_def in class_defs:
        class_names = re.findall(
            r"class +(\w+)[\w\W]+ForeignKey[\w\W]+Post", class_def
        )
        for name in class_names:
            if name not in known_class_names:
                comment_class_name = name
                break
        if comment_class_name:
            break
    assert comment_class_name, (
        "Убедитесь, что в файле `blog/models.py` объявлена модель комментария"
        " с полем `ForeignKey`, связывающим её с моделью `Post`."
    )
    return getattr(models, comment_class_name)


class ItemNotCreatedException(Exception):
    """
    Исключение, вызываемое, если объект не был создан.
    """
    ...

# Вспомогательные функции для тестирования и фикстуры

from django.db.models import Model, Field
from django.forms import BaseForm
from django.http import HttpResponse
from django.test import Client
from http import HTTPStatus
from typing import Union, Any, List, Tuple, Optional
import os
import re
import time
from pathlib import Path
import pytest

# --- Вспомогательные функции ---

def get_get_response_safely(
        user_client: Client, url: str, err_msg: Optional[str] = None,
        expected_status=HTTPStatus.OK
) -> HttpResponse:
    """
    Безопасно получает GET-ответ для указанного URL.

    :param user_client: Клиент Django.
    :param url: URL страницы.
    :param err_msg: Сообщение об ошибке при несоответствии статуса.
    :param expected_status: Ожидаемый статус ответа.
    """
    response = user_client.get(url)
    if err_msg is not None:
        assert response.status_code == expected_status, err_msg
    return response


def get_a_post_get_response_safely(
        user_client: Client, post_id: Union[str, int]
) -> HttpResponse:
    """
    Получает страницу публикации для указанного поста.

    :param user_client: Клиент Django.
    :param post_id: ID поста.
    """
    return get_get_response_safely(
        user_client,
        url=f"/posts/{post_id}/",
        err_msg=(
            "Убедитесь, что опубликованный пост с опубликованной категорией и"
            " датой публикации в прошлом отображается на странице публикации."
        ),
    )


def get_create_a_post_get_response_safely(user_client: Client) -> HttpResponse:
    """
    Получает страницу создания публикации.

    :param user_client: Клиент Django.
    """
    url = "/posts/create/"
    return get_get_response_safely(
        user_client,
        url=url,
        err_msg=(
            "Убедитесь, что страница создания публикации по адресу"
            f" {url} отображается без ошибок."
        ),
    )


def _testget_context_item_by_class(
        context, cls: type, err_msg: str, inside_iter: bool = False
) -> KeyVal:
    """
    Находит элемент контекста, соответствующий указанному классу.

    :param context: Контекст страницы.
    :param cls: Класс, который нужно найти.
    :param err_msg: Сообщение об ошибке.
    :param inside_iter: Проверять содержимое итератора?
    """
    def is_a_match(val: Any):
        if inside_iter:
            try:
                return isinstance(iter(val).__next__(), cls)
            except Exception:
                return False
        else:
            return isinstance(val, cls)

    matched_keyval = KeyVal(key=None, val=None)
    matched_keyvals: List[KeyVal] = []
    for key, val in dict(context).items():
        if is_a_match(val):
            matched_keyval = KeyVal(key, val)
            matched_keyvals.append(matched_keyval)
    if err_msg:
        assert len(matched_keyvals) == 1, err_msg
        assert matched_keyval.key, err_msg

    return matched_keyval


def _testget_context_item_by_key(context, key: str, err_msg: str) -> KeyVal:
    """
    Находит элемент контекста по ключу.

    :param context: Контекст страницы.
    :param key: Ключ элемента.
    :param err_msg: Сообщение об ошибке.
    """
    context_as_dict = dict(context)
    if key not in context_as_dict:
        raise AssertionError(err_msg)
    return KeyVal(key, context_as_dict[key])


def get_page_context_form(user_client: Client, page_url: str) -> KeyVal:
    """
    Возвращает форму из контекста страницы.

    :param user_client: Клиент Django.
    :param page_url: URL страницы.
    """
    response = user_client.get(page_url)
    if not str(response.status_code).startswith("2"):
        return KeyVal(key=None, val=None)
    return _testget_context_item_by_class(response.context, BaseForm, "")


def restore_cleaned_data(cleaned_data: dict) -> dict:
    """
    Восстанавливает исходные данные из очищенных данных формы.

    :param cleaned_data: Очищенные данные формы.
    """
    return {
        k: v.id if isinstance(v, Model) else v for k, v in cleaned_data.items()
    }


def squash_code(code: str) -> str:
    """
    Упрощает код, удаляя комментарии и пробелы.

    :param code: Исходный код.
    """
    result = re.sub(r"#.+", "", code)
    return result.replace("\n", "").replace(" ", "")


def get_field_key(field_type: type, field: Field) -> Tuple[str, Optional[str]]:
    """
    Возвращает ключ для поля модели.

    :param field_type: Тип поля.
    :param field: Поле модели.
    """
    if field.is_relation:
        return (field_type.__name__, field.related_model.__name__)
    else:
        return (field_type.__name__, None)


# --- Фикстуры ---

@pytest.fixture(scope="session", autouse=True)
def cleanup(request):
    """
    Очищает временные файлы после выполнения тестов.

    :param request: Объект запроса.
    """
    start_time = time.time()

    yield

    from blogicum import settings

    image_dir = Path(settings.__file__).parent.parent / settings.MEDIA_ROOT

    for root, dirs, files in os.walk(image_dir):
        for filename in files:
            if filename.endswith((".jpg", ".gif", ".png")):
                file_path = os.path.join(root, filename)
                if os.path.getmtime(file_path) >= start_time:
                    os.remove(file_path)

