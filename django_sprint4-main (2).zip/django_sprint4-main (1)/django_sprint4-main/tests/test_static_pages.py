"""
Тестирование подключения статических страниц с использованием CBV (Class-Based Views).

Этот тест проверяет:
1. Корректность импорта файла `pages/urls.py` и его структуры.
2. Наличие списка `urlpatterns` в `pages/urls.py`.
3. Наличие глобальной переменной `app_name`, определяющей пространство имен для приложения.
4. Подключение маршрутов статических страниц через CBV (Class-Based Views).
"""
def test_static_pages_as_cbv():
    # Проверка импорта файла `pages/urls.py`
    try:
        from pages import urls
    except Exception as e:
        raise AssertionError(
            "Убедитесь, что в файле `pages/urls.py` нет ошибок. При его"
            f" импорте возникла ошибка:\n{type(e).__name__}: {e}"
        )

    # Проверка наличия списка `urlpatterns`
    try:
        from pages.urls import urlpatterns
    except Exception:
        raise AssertionError(
            "Убедитесь, что в файле `pages/urls.py` задан список urlpatterns."
        )

    # Проверка наличия глобальной переменной `app_name`
    try:
        from pages.urls import app_name
    except Exception:
        raise AssertionError(
            "Убедитесь, что в файле `pages/urls.py` определена глобальная"
            " переменная `app_name`, задающая пространство имён url для"
            " приложения `pages`."
        )

    # Проверка, что маршруты подключены через CBV
    for path in urlpatterns:
        if not hasattr(path.callback, "view_class"):
            raise AssertionError(
                "Убедитесь, что в файле `pages/urls.py` маршруты статических"
                " страниц подключены с помощью CBV."
            )
