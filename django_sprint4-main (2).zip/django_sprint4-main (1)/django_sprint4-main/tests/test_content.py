"""
Тестирование отображения и функциональности контента на страницах профиля, категорий и главной страницы.

Данный модуль включает тесты для проверки отображения публикаций, пагинации, видимости изображений,
а также работы с публикациями, снятыми с публикации или отложенными.
"""
import inspect
from abc import abstractmethod, ABC
from typing import Type, Optional, Callable, List, Tuple, Union

import pytest
from bs4 import BeautifulSoup
from bs4.element import SoupStrainer
from django.db.models import Model
from django.http import HttpResponse
from django.test.client import Client
from mixer.main import Mixer

from adapters.model_adapter import ModelAdapter
from adapters.post import PostModelAdapter
from conftest import (
    N_PER_PAGE,
    UrlRepr,
    _testget_context_item_by_class,
    _testget_context_item_by_key,
)

pytestmark = [pytest.mark.django_db]


class ContentTester(ABC):
    """
    Абстрактный класс для проверки содержимого страниц.
    """

    n_per_page = N_PER_PAGE  # Количество элементов на одной странице

    def __init__(
        self,
        mixer: Mixer,
        item_cls: Type[Model],
        adapter_cls: Type[ModelAdapter],
        user_client: Client,
        page_url: Optional[UrlRepr] = None,
        another_user_client: Optional[Client] = None,
        unlogged_client: Optional[Client] = None,
    ):
        """
        Инициализация тестировщика содержимого.

        :param mixer: Экземпляр Mixer для генерации данных.
        :param item_cls: Класс модели для проверки.
        :param adapter_cls: Адаптер для взаимодействия с моделью.
        :param user_client: Клиент авторизованного пользователя.
        :param page_url: URL-адрес страницы.
        :param another_user_client: Клиент другого авторизованного пользователя.
        :param unlogged_client: Клиент неавторизованного пользователя.
        """
        self._mixer = mixer
        self._items_key = None
        self._page_url = page_url
        self.item_cls = item_cls
        self.adapter_cls = adapter_cls
        self.user_client = user_client
        self.another_user_client = another_user_client
        self.unlogged_client = unlogged_client

    @property
    def page_url(self):
        return self._page_url

    @property
    @abstractmethod
    def items_hardcoded_key(self):
        """
        Абстрактное свойство. Должно возвращать ключ контекста с элементами.
        """
        raise NotImplementedError(
            "Override `items_hardcoded_key` property "
            "in ContentTester`s child class"
        )

    @abstractmethod
    def raise_assert_page_loads_cbk(self):
        """
        Абстрактный метод для вызова при ошибке загрузки страницы.
        """
        raise NotImplementedError

    def user_client_testget(
        self,
        url: Optional[str] = None,
        assert_status_in: Tuple[int] = (200,),
        assert_cbk: Union[
            Callable[[], None], str
        ] = "raise_assert_page_loads_cbk",
    ) -> HttpResponse:
        """
        Отправляет GET-запрос от имени авторизованного пользователя.

        :param url: URL-адрес для запроса.
        :param assert_status_in: Ожидаемые коды статуса ответа.
        :param assert_cbk: Обработчик ошибок.
        :return: HttpResponse
        """
        return self._testget(
            self.user_client, url, assert_status_in, assert_cbk
        )

    def another_client_testget(
        self,
        url: Optional[str] = None,
        assert_status_in: Tuple[int] = (200,),
        assert_cbk: Union[
            Callable[[], None], str
        ] = "raise_assert_page_loads_cbk",
    ) -> HttpResponse:
        """
        Отправляет GET-запрос от имени другого авторизованного пользователя.
        """
        return self._testget(
            self.another_user_client, url, assert_status_in, assert_cbk
        )

    def _testget(
        self,
        client,
        url: Optional[str] = None,
        assert_status_in: Tuple[int] = (200,),
        assert_cbk: Union[
            Callable[[], None], str
        ] = "raise_assert_page_loads_cbk",
    ) -> HttpResponse:
        """
        Универсальный метод для отправки GET-запроса.

        :param client: Клиент, выполняющий запрос.
        :param url: URL-адрес для запроса.
        :param assert_status_in: Ожидаемые коды статуса ответа.
        :param assert_cbk: Обработчик ошибок.
        :return: HttpResponse
        """
        url = url or self.page_url.url
        try:
            response = client.get(url)
            if response.status_code not in assert_status_in:
                raise Exception
        except Exception:
            if inspect.isfunction(assert_cbk):
                assert_cbk()
            elif isinstance(assert_cbk, str):
                getattr(self, assert_cbk)()
            else:
                raise AssertionError("Wrong type of `assert_cbk` argument.")

        return response

    @abstractmethod
    def items_key_error_message(self):
        """
        Абстрактный метод для сообщения об ошибке ключа контекста.
        """
        raise NotImplementedError

    @abstractmethod
    def items_hardcoded_key_error_message(self):
        """
        Абстрактный метод для сообщения об ошибке при жестко заданном ключе.
        """
        raise NotImplementedError

    @property
    def items_key(self):
        """
        Возвращает ключ контекста с элементами.
        """
        if self._items_key:
            return self._items_key

        def setup_for_url(setup_items: List[Model]) -> UrlRepr:
            """
            Устанавливает временные данные для тестов.

            :param setup_items: Список временных объектов.
            :return: UrlRepr
            """
            temp_category = self._mixer.blend(
                "blog.Category", is_published=True
            )
            temp_location = self._mixer.blend(
                "blog.Location", is_published=True
            )
            temp_post = self._mixer.blend(
                "blog.Post",
                is_published=True,
                location=temp_location,
                category=temp_category,
            )
            setup_items.extend([temp_category, temp_location, temp_post])
            url_repr = self.page_url
            return url_repr

        def teardown(setup_items: List[Model]):
            """
            Удаляет временные данные после тестов.
            """
            while setup_items:
                item = setup_items.pop()
                item.delete()

        setup_items = []

        try:
            url_repr = setup_for_url(setup_items)
            context = self.user_client_testget(url=url_repr.url).context
            if self.items_hardcoded_key:
                key_val = _testget_context_item_by_key(
                    context,
                    self.items_hardcoded_key,
                    err_msg=self.items_hardcoded_key_error_message(),
                )
            else:
                key_val = _testget_context_item_by_class(
                    context,
                    self.item_cls,
                    err_msg=self.items_key_error_message(),
                    inside_iter=True,
                )
        finally:
            teardown(setup_items)

        return key_val.key

    class PostContentTester(ContentTester):
        """
        Базовый класс для проверки контента публикаций на различных страницах.
        """

        @property
        def items_hardcoded_key(self):
            """
            Жестко заданный ключ для получения публикаций из контекста страницы.
            """
            return "page_obj"

        @abstractmethod
        def raise_assert_page_loads_cbk(self):
            """
            Метод вызывается при ошибке загрузки страницы.
            """
            raise NotImplementedError

        @property
        @abstractmethod
        def image_display_error(self) -> str:
            """
            Сообщение об ошибке, если изображения публикаций не отображаются.
            """
            raise NotImplementedError

    class ProfilePostContentTester(PostContentTester):
        """
        Тестер для проверки контента страницы профиля.
        """

        def items_key_error_message(self):
            return (
                "Убедитесь, что существует ровно один ключ, под которым в словарь"
                " контекста страницы пользователя передаются публикации."
            )

        def items_hardcoded_key_error_message(self):
            return (
                "Убедитесь, что в словарь контекста страницы пользователя"
                f" публикации передаются под ключом `{self.items_hardcoded_key}`."
            )

        def raise_assert_page_loads_cbk(self):
            raise AssertionError(
                "Убедитесь, что страница пользователя загружается без ошибок."
            )

        @property
        def image_display_error(self) -> str:
            return (
                "Убедитесь, что на странице профиля автора отображаются"
                " изображения публикаций."
            )

    class MainPostContentTester(PostContentTester):
        """
        Тестер для проверки контента главной страницы.
        """

        def items_key_error_message(self):
            return (
                "Убедитесь, что существует ровно один ключ, под которым в словарь"
                " контекста главной страницы передаются публикации."
            )

        def items_hardcoded_key_error_message(self):
            return (
                "Убедитесь, что в словарь контекста главной страницы публикации"
                f" передаются под ключом `{self.items_hardcoded_key}`."
            )

        def raise_assert_page_loads_cbk(self):
            raise AssertionError(
                "Убедитесь, что главная страница загружается без ошибок."
            )

        @property
        def image_display_error(self) -> str:
            return (
                "Убедитесь, что на главной странице видны прикреплённые к постам"
                " изображения."
            )

    class CategoryPostContentTester(PostContentTester):
        """
        Тестер для проверки контента страницы категории.
        """

        @property
        def page_url(self):
            """
            URL-адрес страницы категории.
            """
            if not self._page_url:
                from blog.models import Category

                category = Category.objects.first()
                if category:
                    self._page_url = UrlRepr(
                        f"/category/{category.slug}/", "/category/<category_slug>/"
                    )
            return self._page_url

        def items_key_error_message(self):
            return (
                "Убедитесь, что существует ровно один ключ, под которым в словарь"
                " контекста страницы категории передаются публикации."
            )

        def items_hardcoded_key_error_message(self):
            return (
                "Убедитесь, что в словарь контекста страницы категории публикации"
                f" передаются под ключом `{self.items_hardcoded_key}`."
            )

        def raise_assert_page_loads_cbk(self):
            raise AssertionError(
                "Убедитесь, что страница категории загружается без ошибок."
            )

        @property
        def image_display_error(self) -> str:
            return (
                "Убедитесь, что на странице категории видны прикреплённые к постам"
                " изображения."
            )

    @pytest.fixture
    def profile_content_tester(
            user: Model,
            mixer: Mixer,
            PostModel: Type[Model],
            user_client: Client,
            another_user_client: Client,
            unlogged_client: Client,
    ) -> ProfilePostContentTester:
        """
        Фикстура для создания экземпляра тестера страницы профиля.

        :param user: Текущий пользователь.
        :param mixer: Инструмент для генерации данных.
        :param PostModel: Модель публикации.
        :param user_client: Клиент авторизованного пользователя.
        :param another_user_client: Клиент другого пользователя.
        :param unlogged_client: Клиент неавторизованного пользователя.
        :return: Экземпляр ProfilePostContentTester.
        """
        url_repr = UrlRepr(f"/profile/{user.username}/", "/profile/<username>/")
        return ProfilePostContentTester(
            mixer,
            PostModel,
            PostModelAdapter,
            user_client,
            url_repr,
            another_user_client,
        )


@pytest.fixture
def main_content_tester(
    user: Model,
    mixer: Mixer,
    PostModel: Type[Model],
    user_client: Client,
    another_user_client: Client,
    unlogged_client: Client,
) -> MainPostContentTester:
    """
    Фикстура для тестирования контента на главной странице.

    :param user: Пользователь.
    :param mixer: Генератор данных.
    :param PostModel: Модель публикации.
    :param user_client: Клиент авторизованного пользователя.
    :param another_user_client: Клиент другого пользователя.
    :param unlogged_client: Клиент неавторизованного пользователя.
    :return: Экземпляр MainPostContentTester.
    """
    url_repr = UrlRepr("/", "/")
    return MainPostContentTester(
        mixer, PostModel, PostModelAdapter, user_client, url_repr
    )


@pytest.fixture
def category_content_tester(
    user: Model,
    mixer: Mixer,
    PostModel: Type[Model],
    user_client: Client,
    another_user_client: Client,
    unlogged_client: Client,
) -> CategoryPostContentTester:
    """
    Фикстура для тестирования контента на странице категории.

    :param user: Пользователь.
    :param mixer: Генератор данных.
    :param PostModel: Модель публикации.
    :param user_client: Клиент авторизованного пользователя.
    :param another_user_client: Клиент другого пользователя.
    :param unlogged_client: Клиент неавторизованного пользователя.
    :return: Экземпляр CategoryPostContentTester.
    """
    return CategoryPostContentTester(
        mixer, PostModel, PostModelAdapter, user_client
    )


class TestContent:
    """
    Тесты для проверки контента на страницах профиля, главной и категории.
    """

    @pytest.fixture(autouse=True)
    def init(
        self,
        profile_content_tester,
        main_content_tester,
        category_content_tester,
    ):
        """
        Инициализация тестеров контента.

        :param profile_content_tester: Тестер страницы профиля.
        :param main_content_tester: Тестер главной страницы.
        :param category_content_tester: Тестер страницы категории.
        """
        self.profile_tester = profile_content_tester
        self.main_tester = main_content_tester
        self.category_tester = category_content_tester

    def test_unpublished(self, unpublished_posts_with_published_locations):
        """
        Проверка: непубликуемые посты видны только автору.
        """
        profile_response = self.profile_tester.user_client_testget()
        context_posts = profile_response.context.get(
            self.profile_tester.items_key
        )
        expected_n = self.profile_tester.n_or_page_size(
            len(unpublished_posts_with_published_locations)
        )
        assert len(context_posts) == expected_n, (
            "Убедитесь, что автор видит свои посты, снятые с публикации, на странице профиля."
        )

        response = self.main_tester.user_client_testget()
        try:
            items_key = self.main_tester.items_key
        except AssertionError:
            pass
        else:
            context_posts = response.context.get(items_key)
            assert len(context_posts) == 0, (
                "Убедитесь, что на главной странице не отображаются снятые с публикации посты."
            )

        response = self.category_tester.user_client_testget()
        try:
            items_key = self.category_tester.items_key
        except AssertionError:
            pass
        else:
            context_posts = response.context.get(items_key)
            assert len(context_posts) == 0, (
                "Убедитесь, что на странице категории не отображаются снятые с публикации посты."
            )

    def test_only_own_pubs_in_category(
        self, user_client, post_with_published_location, post_with_another_category
    ):
        """
        Проверка: в категории отображаются только публикации данной категории.
        """
        response = self.category_tester.user_client_testget()
        try:
            items_key = self.category_tester.items_key
        except AssertionError:
            pass
        else:
            context_posts = response.context.get(items_key)
            assert (
                len(context_posts) == 1
            ), "Убедитесь, что в категории отображаются только соответствующие публикации."

    def test_only_own_pubs_in_profile(
        self, user_client, post_with_published_location, post_of_another_author
    ):
        """
        Проверка: на странице профиля отображаются только публикации данного автора.
        """
        response = self.profile_tester.user_client_testget()
        try:
            items_key = self.profile_tester.items_key
        except AssertionError:
            pass
        else:
            context_posts = response.context.get(items_key)
            assert (
                len(context_posts) == 1
            ), "Убедитесь, что в профиле отображаются только публикации данного автора."

    def test_unpublished_category(
        self, user_client, posts_with_unpublished_category
    ):
        """
        Проверка: посты с неопубликованной категорией видны только автору.
        """
        profile_response = self.profile_tester.user_client_testget()
        context_posts = profile_response.context.get(
            self.profile_tester.items_key
        )
        expected_n = self.profile_tester.n_or_page_size(
            len(posts_with_unpublished_category)
        )
        assert len(context_posts) == expected_n, (
            "Убедитесь, что автор видит свои посты с неопубликованной категорией."
        )

        main_response = self.main_tester.user_client_testget()
        context_posts = main_response.context.get(self.main_tester.items_key)
        assert len(context_posts) == 0, (
            "Убедитесь, что на главной странице не отображаются посты с неопубликованной категорией."
        )

        def raise_assert_not_exist_cbk():
            """
            Callback для проверки отсутствия страницы категории, если категория снята с публикации.
            """
            raise AssertionError(
                "Убедитесь, что страница категории недоступна, если категория"
                " снята с публикации."
            )

        self.category_tester.user_client_testget(
            assert_status_in=(404,), assert_cbk=raise_assert_not_exist_cbk
        )

        def test_future_posts(self, user_client, future_posts):
            """
            Проверка: будущие публикации видны только автору.
            """
            profile_response = self.profile_tester.user_client_testget()
            context_posts = profile_response.context.get(
                self.profile_tester.items_key
            )
            expected_n = self.profile_tester.n_or_page_size(len(future_posts))
            assert len(context_posts) == expected_n, (
                "Убедитесь, что на странице пользователя автор может видеть свои"
                " отложенные публикации."
            )

            response = self.main_tester.user_client_testget()
            try:
                items_key = self.main_tester.items_key
            except AssertionError:
                pass
            else:
                context_posts = response.context.get(items_key)
                assert len(context_posts) == 0, (
                    "Убедитесь, что на главной странице не отображаются отложенные публикации."
                )

            response = self.category_tester.user_client_testget()
            try:
                items_key = self.category_tester.items_key
            except AssertionError:
                pass
            else:
                context_posts = response.context.get(items_key)
                assert len(context_posts) == 0, (
                    "Убедитесь, что на странице категории не отображаются отложенные публикации."
                )

        def test_pagination(
                self, user_client, many_posts_with_published_locations
        ):
            """
            Проверка: работает ли пагинация на страницах с большим количеством публикаций.
            """
            posts = many_posts_with_published_locations

            assert len(posts) > self.profile_tester.n_per_page
            assert len(posts) > self.main_tester.n_per_page
            assert len(posts) > self.category_tester.n_per_page

            for (
                    tester,
                    response_get_func,
                    ordering_err_msg,
                    pagination_err_msg,
            ) in (
                    (
                            self.profile_tester,
                            self.profile_tester.user_client_testget,
                            (
                                    "Убедитесь, что публикации на странице профиля отсортированы"
                                    " по времени публикации в порядке убывания."
                            ),
                            (
                                    "Убедитесь, что на странице профиля работает пагинация."
                            ),
                    ),
                    (
                            self.main_tester,
                            self.main_tester.user_client_testget,
                            (
                                    "Убедитесь, что публикации на главной странице отсортированы"
                                    " по времени публикации в порядке убывания."
                            ),
                            "Убедитесь, что на главной странице работает пагинация.",
                    ),
                    (
                            self.category_tester,
                            self.category_tester.user_client_testget,
                            (
                                    "Убедитесь, что публикации на странице категории отсортированы"
                                    " по времени публикации в порядке убывания."
                            ),
                            "Убедитесь, что на странице категории работает пагинация.",
                    ),
            ):
                response = response_get_func()
                context_posts = response.context.get(tester.items_key)
                pub_dates = [x.pub_date for x in context_posts]
                if pub_dates != sorted(pub_dates, reverse=True):
                    raise AssertionError(ordering_err_msg)
                expected_n = tester.n_or_page_size(len(posts))
                assert len(context_posts) == expected_n, pagination_err_msg

        def test_image_visible(self, user_client, post_with_published_location):
            """
            Проверка: отображаются ли изображения публикаций на страницах.
            """
            post = post_with_published_location
            post_adapter = PostModelAdapter(post)

            testers: List[PostContentTester] = [
                self.profile_tester,
                self.main_tester,
                self.category_tester,
            ]
            img_n_with_post_img = {}

            # Считаем количество изображений с прикреплённой картинкой поста
            for i, tester in enumerate(testers):
                img_soup_with_post_img = BeautifulSoup(
                    tester.user_client_testget().content.decode("utf-8"),
                    features="html.parser",
                    parse_only=SoupStrainer("img"),
                )
                img_n_with_post_img[i] = len(img_soup_with_post_img)

            # Удаляем изображение из поста
            post_adapter.image = None
            post_adapter.save()

            # Проверяем разницу в количестве изображений
            for i, tester in enumerate(testers):
                img_soup_without_post_img = BeautifulSoup(
                    tester.user_client_testget().content.decode("utf-8"),
                    features="html.parser",
                    parse_only=SoupStrainer("img"),
                )
                img_n_without_post_img = len(img_soup_without_post_img)
                assert (
                               img_n_with_post_img[i] - img_n_without_post_img
                       ) == 1, tester.image_display_error
