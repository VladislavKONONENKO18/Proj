"""
Модуль для тестирования форм создания публикаций.

На что обратить внимание:
- Создание и тестирование форм, содержащих поле для изображения.
- Функции обеспечивают генерацию тестовых данных, включая загрузку файлов.
- Все методы соответствуют требованиям автотестов и обрабатывают изображения корректно.
"""
from io import BytesIO
from typing import Type, Dict

from PIL import Image
from django.core.files.uploadedfile import SimpleUploadedFile
from django.forms import BaseForm

from adapters.post import PostModelAdapter
from form.base_form_tester import BaseFormTester


class PostFormTester(BaseFormTester):
    """
    Класс для тестирования форм публикаций.
    Обеспечивает создание и тестирование форм с учетом полей для изображений.
    """

    @property
    def has_textarea(self):
        """Проверяет, содержит ли форма поле textarea."""
        return True

    @staticmethod
    def init_create_item_form(Form: Type[BaseForm], **form_data) -> BaseForm:
        """
        Инициализирует форму для создания объекта публикации с изображением.

        Args:
            Form (Type[BaseForm]): Класс формы.
            **form_data: Данные для заполнения формы.

        Returns:
            BaseForm: Инициализированная форма.
        """
        image_data = BytesIO()
        Image.new("RGB", (100, 100)).save(image_data, "JPEG")
        image_data.seek(0)
        from blog.models import Post

        files = {
            PostModelAdapter(Post).get_student_field_name(
                "image"
            ): SimpleUploadedFile(
                "test_image.jpg", image_data.read(), content_type="image/jpeg"
            ),
        }

        result = Form(data=form_data, files=files)
        return result

    @staticmethod
    def generate_files_dict() -> Dict[str, SimpleUploadedFile]:
        """
        Генерирует словарь с загруженными файлами для формы.

        Returns:
            Dict[str, SimpleUploadedFile]: Словарь с полем для изображения.
        """
        image_data = BytesIO()
        Image.new("RGB", (100, 100)).save(image_data, "JPEG")
        image_data.seek(0)
        from blog.models import Post

        files = {
            PostModelAdapter(Post).get_student_field_name(
                "image"
            ): SimpleUploadedFile(
                "test_image.jpg", image_data.read(), content_type="image/jpeg"
            ),
        }
        return files
