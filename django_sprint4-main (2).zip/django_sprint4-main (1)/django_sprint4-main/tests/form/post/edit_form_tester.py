"""
Класс EditPostFormTester для тестирования формы редактирования постов.

Класс предоставляет методы для проверки корректности формы редактирования поста,
включая валидацию, права доступа, правильность перенаправлений и отображения изменений.
"""

from typing import Tuple, Union

import bs4
from django.db.models import QuerySet, Model
from django.forms import BaseForm
from django.http import HttpResponse

from conftest import TitledUrlRepr, UrlRepr
from fixtures.types import ModelAdapterT
from form.base_form_tester import (
    FormTagMissingException,
    FormMethodException,
    TextareaMismatchException,
    TextareaTagMissingException,
)
from form.base_form_tester import (
    SubmitTester,
    FormValidationException,
    UnauthorizedEditException,
    UnauthenticatedEditException,
    AuthenticatedEditException,
    DatabaseCreationException,
    ItemCreatedException,
)
from form.base_form_tester import (
    UnauthorizedSubmitTester,
    AnonymousSubmitTester,
)
from form.post.form_tester import PostFormTester


class EditPostFormTester(PostFormTester):
    """
    Класс для тестирования формы редактирования поста.
    """

    def __init__(
        self,
        response: HttpResponse,
        *args,
        ModelAdapter: ModelAdapterT,
        **kwargs,
    ):
        """
        Инициализация тестера формы редактирования поста.

        Args:
            response: Ответ, содержащий форму редактирования поста.
        """
        try:
            super().__init__(
                response, *args, ModelAdapter=ModelAdapter, **kwargs
            )
        except FormTagMissingException as e:
            raise AssertionError(
                "Убедитесь, что на страницу редактирования поста передаётся"
                " форма."
            ) from e

    @property
    def unauthorized_edit_redirect_cbk(self):
        """
        Проверка перенаправления для неавтора поста.
        """
        redirect_to_page: TitledUrlRepr = (
            UrlRepr(r"/posts/\d+/$", "/posts/<int:post_id>/"),
            "страницу публикации",
        )
        return UnauthorizedSubmitTester.get_test_response_redirect_cbk(
            tester=self, redirect_to_page=redirect_to_page
        )

    @property
    def anonymous_edit_redirect_cbk(self):
        """
        Проверка перенаправления для анонимного пользователя.
        """
        return AnonymousSubmitTester.get_test_response_redirect_cbk(
            tester=self, redirect_to_page="страницу аутентификации"
        )

    @property
    def textarea_tag(self) -> bs4.Tag:
        """
        Проверка наличия текстового поля для редактирования основного текста поста.
        """
        try:
            return super().textarea_tag
        except TextareaTagMissingException as e:
            raise AssertionError(
                "Убедитесь, что в форме редактирования поста есть элемент"
                " `textarea`."
            ) from e

    def _validate(self):
        """
        Валидация формы редактирования поста.
        """
        try:
            super()._validate()
        except FormTagMissingException as e:
            raise AssertionError(
                "Убедитесь, что на страницу редактирования поста передаётся"
                " форма."
            ) from e
        except FormMethodException as e:
            raise AssertionError(
                "Убедитесь, что форма для редактирования поста отправляется"
                " методом `POST`."
            ) from e
        except TextareaMismatchException as e:
            raise AssertionError(
                "Убедитесь, что в форме редактирования поста основной текст"
                " передаётся в поле типа `textarea`."
            ) from e

    def test_edit_item(
        self, updated_form: BaseForm, qs: QuerySet, item_adapter: ModelAdapterT
    ) -> HttpResponse:
        """
        Тестирование редактирования поста.

        Args:
            updated_form: Обновлённая форма редактирования.
            qs: QuerySet объектов.
            item_adapter: Адаптер редактируемого объекта.
        """
        try:
            return super().test_edit_item(updated_form, qs, item_adapter)
        except UnauthorizedEditException:
            raise AssertionError(
                "Убедитесь, что пользователь не может редактировать чужие"
                " посты."
            )
        except UnauthenticatedEditException:
            raise AssertionError(
                "Убедитесь, что неаутентифицированный пользователь не может"
                " редактировать посты."
            )
        except AuthenticatedEditException:
            raise AssertionError(
                "Убедитесь, что пользователь может редактировать свои посты."
            )
        except DatabaseCreationException:
            raise AssertionError(
                "Убедитесь, что при редактировании поста в базе данных не"
                " создаётся новый объект поста."
            )

    def redirect_error_message(
            self, by_user: str, redirect_to_page: Union[TitledUrlRepr, str]
    ) -> str:
        """
        Формирование сообщения об ошибке перенаправления при редактировании поста.

        Args:
            by_user: Описание пользователя, отправляющего форму.
            redirect_to_page: Страница, на которую должно произойти перенаправление.

        Returns:
            Сообщение об ошибке.
        """
        redirect_to_page_repr = self.get_redirect_to_page_repr(
            redirect_to_page
        )
        return (
            "Убедитесь, что при отправке формы редактирования поста"
            f" {by_user} он перенаправляется на {redirect_to_page_repr}."
        )

    def status_error_message(self, by_user: str) -> str:
        """
        Формирование сообщения об ошибке статуса при отправке формы редактирования поста.

        Args:
            by_user: Описание пользователя, отправляющего форму.

        Returns:
            Сообщение об ошибке.
        """
        return (
            "Убедитесь, что при отправке формы редактирования поста"
            f" {by_user} не возникает ошибок."
        )

    @property
    def author_assignment_error_message(self) -> str:
        """
        Формирование сообщения об ошибке, связанной с автором поста.

        Returns:
            Сообщение об ошибке.
        """
        return (
            "Убедитесь, что в форму редактирования поста в поле «автор»"
            " передаётся аутентифицированный пользователь."
        )

    @property
    def display_text_error_message(self) -> str:
        """
        Формирование сообщения об ошибке отображения текста поста.

        Returns:
            Сообщение об ошибке.
        """
        return (
            "Убедитесь, что после редактирования поста новый текст"
            " отображается на странице поста."
        )

    def validation_error_message(self, student_form_fields_str: str) -> str:
        """
        Формирование сообщения об ошибке валидации формы редактирования поста.

        Args:
            student_form_fields_str: Список полей, необходимых для валидации.

        Returns:
            Сообщение об ошибке.
        """
        return (
            "Убедитесь, что для валидации формы редактирования поста"
            f" достаточно заполнить следующие поля: {student_form_fields_str}."
        )

    @property
    def item_not_created_assertion_msg(self):
        """
        Сообщение об ошибке создания нового объекта поста.

        Returns:
            Сообщение об ошибке.
        """
        return (
            "Убедитесь, что при отправке формы редактирования публикации"
            " авторизованным пользователем  в базе данных не создаётся новый"
            " объект поста."
        )

    @property
    def wrong_author_assertion_msg(self):
        """
        Сообщение об ошибке неверного автора при редактировании поста.

        Returns:
            Сообщение об ошибке.
        """
        return (
            "Убедитесь, что при редактировании поста в форму в поле «автор»"
            " передаётся аутентифицированный пользователь."
        )

    def creation_assertion_msg(self, prop):
        """
        Формирование сообщения об ошибке отображения значения поля после редактирования поста.

        Args:
            prop: Название поля, которое проверяется.

        Returns:
            Сообщение об ошибке.
        """
        return (
            "Убедитесь, что после отправки формы редактирования поста"
            " правильно работает переадресация. Проверьте, что значение поля"
            f" `{prop}` отображается на странице поста."
        )
