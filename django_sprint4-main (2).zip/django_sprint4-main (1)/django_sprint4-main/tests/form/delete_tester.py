# Тестер удаления объектов для моделей Django

from abc import abstractmethod
from typing import Set, Tuple, Optional, Union

from django.db.models import QuerySet, Model
from django.http import HttpResponse

from conftest import TitledUrlRepr
from form.base_form_tester import (
    UnauthorizedSubmitTester,
    AnonymousSubmitTester,
    AuthorisedSubmitTester,
    SubmitTester,
)
from form.base_tester import BaseTester


class DeleteTester(BaseTester):
    """
    Класс для тестирования удаления объектов моделей Django.

    Проверяет:
    - Возможность удаления объекта только авторизованным пользователем.
    - Корректность редиректов.
    - Гарантию, что удаляется только один объект.
    """

    @property
    @abstractmethod
    def unauthenticated_user_error(self):
        """Сообщение об ошибке, если неаутентифицированный пользователь пытается удалить объект."""
        raise NotImplementedError

    @property
    @abstractmethod
    def anonymous_user_error(self):
        """Сообщение об ошибке, если анонимный пользователь пытается удалить объект."""
        raise NotImplementedError

    @property
    @abstractmethod
    def successful_delete_error(self):
        """Сообщение об ошибке, если объект не был успешно удалён."""
        raise NotImplementedError

    @property
    @abstractmethod
    def only_one_delete_error(self):
        """Сообщение об ошибке, если удалено больше одного объекта."""
        raise NotImplementedError

    @abstractmethod
    def status_error_message(self, by_user: str) -> str:
        """Сообщение об ошибке, если статус ответа некорректен."""
        raise NotImplementedError

    @abstractmethod
    def redirect_error_message(
            self, by_user: str, redirect_to_page: Union[TitledUrlRepr, str]
    ):
        """Сообщение об ошибке при некорректном редиректе."""
        raise NotImplementedError

    def get_redirect_to_page_repr(self, redirect_to_page):
        """
        Возвращает читаемое представление ожидаемой страницы редиректа.

        :param redirect_to_page: Ожидаемая страница редиректа.
        :return: Строковое представление страницы редиректа.
        """
        if isinstance(redirect_to_page, str):
            redirect_to_page_repr = redirect_to_page
        elif isinstance(redirect_to_page, tuple):  # expected TitledUrlRepr
            (
                redirect_pattern,
                redirect_repr,
            ), redirect_title = redirect_to_page
            redirect_to_page_repr = f"{redirect_title} ({redirect_repr})"
        else:
            raise AssertionError(
                f"Unexpected value type `{type(redirect_to_page)}` "
                "for `redirect_to_page`"
            )
        return redirect_to_page_repr

    def test_delete_item(
            self, qs: QuerySet, delete_url_addr: str
    ) -> HttpResponse:
        """
        Тестирует процесс удаления объекта.

        Проверяет:
        - Удаление недоступно неаутентифицированному пользователю.
        - Удаление недоступно анонимному пользователю.
        - Удаление доступно авторизованному пользователю.
        - После удаления объект отсутствует в базе.

        :param qs: QuerySet с объектами для теста.
        :param delete_url_addr: URL для отправки запроса на удаление.
        :return: Ответ сервера для авторизованного пользователя.
        """
        instances_before: Set[Model] = set(qs.all())

        # Тест неаутентифицированного пользователя
        can_delete, response = self.user_can_delete(
            UnauthorizedSubmitTester(tester=self, test_response_cbk=None),
            delete_url_addr,
            self._item_adapter,
            qs=qs,
        )
        assert not can_delete, self.unauthenticated_user_error

        # Тест анонимного пользователя
        can_delete, response = self.user_can_delete(
            AnonymousSubmitTester(tester=self, test_response_cbk=None),
            delete_url_addr,
            self._item_adapter,
            qs=qs,
        )
        assert not can_delete, self.anonymous_user_error

        # Тест авторизованного пользователя
        can_delete, response = self.user_can_delete(
            AuthorisedSubmitTester(
                tester=self,
                test_response_cbk=(
                    AuthorisedSubmitTester.get_test_response_ok_cbk(
                        tester=self
                    )
                ),
            ),
            delete_url_addr,
            self._item_adapter,
            qs=qs,
        )
        assert can_delete, self.successful_delete_error

        instances_after: Set[Model] = set(qs.all())

        # Проверка, что удалён только один объект
        deleted_instances_n = instances_before - instances_after
        assert len(deleted_instances_n) == 1, self.only_one_delete_error

        return response

    def user_can_delete(
            self,
            submitter: SubmitTester,
            delete_url,
            item_to_delete_adapter,
            qs: QuerySet,
    ) -> Tuple[Optional[bool], Optional[HttpResponse]]:
        """
        Проверяет возможность удаления объекта для указанного submitter.

        :param submitter: Тестировщик отправки запроса.
        :param delete_url: URL для удаления.
        :param item_to_delete_adapter: Адаптер объекта для удаления.
        :param qs: QuerySet для проверки существования объекта.
        :return: Кортеж (bool - был ли объект удалён, HttpResponse - ответ сервера).
        """
        response = submitter.test_submit(url=delete_url, data={})
        deleted = qs.filter(id=item_to_delete_adapter.id).first() is None
        return deleted, response
