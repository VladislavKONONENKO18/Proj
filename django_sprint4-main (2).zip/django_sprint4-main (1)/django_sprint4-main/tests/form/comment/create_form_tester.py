"""
Класс для тестирования формы создания комментариев.

Особенности реализации:
- Проверяет наличие формы создания комментария на странице поста.
- Убедитесь, что форма передается авторизованным пользователям.
- Проверяет корректность поля `textarea` для ввода текста комментария.
- Убедитесь, что отправка формы происходит методом `POST`.
- Проверяет успешное создание комментария в базе данных.
"""

from typing import Tuple, Union

import bs4
from django.db.models import QuerySet, Model
from django.forms import BaseForm
from django.http import HttpResponse

from conftest import TitledUrlRepr
from fixtures.types import ModelAdapterT
from form.base_form_tester import (
    FormTagMissingException,
    FormMethodException,
    TextareaMismatchException,
    TextareaTagMissingException,
)
from form.base_form_tester import (
    SubmitTester,
    FormValidationException,
    BaseFormTester,
    ItemCreatedException,
)


class CreateCommentFormTester(BaseFormTester):
    """
    Класс для проверки корректности работы формы создания комментариев.
    """

    def __init__(
        self,
        response: HttpResponse,
        *args,
        ModelAdapter: ModelAdapterT,
        **kwargs,
    ):
        try:
            super().__init__(
                response, *args, ModelAdapter=ModelAdapter, **kwargs
            )
        except FormTagMissingException as e:
            raise AssertionError(
                "Убедитесь, что для авторизованного пользователя на странице"
                " поста передается форма для создания комментария."
            ) from e

    @property
    def has_textarea(self):
        return True

    @property
    def textarea_tag(self) -> bs4.Tag:
        """
        Возвращает HTML-тег для `textarea` поля формы.
        """
        try:
            return super().textarea_tag
        except TextareaTagMissingException as e:
            raise AssertionError(
                "Убедитесь, что в форме создания комментария есть поле"
                " `textarea` для ввода текста."
            ) from e

    def _validate(self):
        """
        Проверяет корректность настройки формы.
        """
        try:
            super()._validate()
        except FormTagMissingException as e:
            raise AssertionError(
                "Убедитесь, что для авторизованного пользователя на странице"
                " поста передается форма для создания комментария."
            ) from e
        except FormMethodException as e:
            raise AssertionError(
                "Убедитесь, что форма создания комментария отправляется"
                " методом `POST`."
            ) from e
        except TextareaMismatchException as e:
            raise AssertionError(
                "Убедитесь, что в форме текст комментария передается через"
                " поле `textarea`."
            ) from e

    def try_create_item(
        self,
        form: BaseForm,
        qs: QuerySet,
        submitter: SubmitTester,
        assert_created: bool = True,
    ) -> Tuple[HttpResponse, Model]:
        """
        Проверяет создание комментария.
        """
        try:
            return super().try_create_item(form, qs, submitter, assert_created)
        except FormValidationException as e:
            raise AssertionError(
                "При создании комментария возникла ошибка:\n"
                f"{type(e).__name__}: {e}"
            ) from e

    def test_unlogged_cannot_create(
        self, form: BaseForm, qs: QuerySet
    ) -> None:
        """
        Проверяет невозможность создания комментария неавторизованным
        пользователем.
        """
        try:
            super().test_unlogged_cannot_create(form, qs)
        except ItemCreatedException as e:
            raise AssertionError(
                "Убедитесь, что комментарии не создаются для"
                " неавторизованных пользователей."
            ) from e

    def redirect_error_message(
        self, by_user: str, redirect_to_page: Union[TitledUrlRepr, str]
    ) -> str:
        """
        Сообщение об ошибке при перенаправлении после отправки формы.
        """
        redirect_to_page_repr = self.get_redirect_to_page_repr(
            redirect_to_page
        )
        return (
            "Убедитесь, что после отправки формы создания комментария"
            f" {by_user} перенаправляется на {redirect_to_page_repr}."
        )

    def status_error_message(self, by_user: str) -> str:
        """
        Сообщение об ошибке при отправке формы.
        """
        return (
            "Убедитесь, что при отправке формы для создания комментария"
            f" {by_user} не возникает ошибок."
        )

    @property
    def author_assignment_error_message(self) -> str:
        """
        Сообщение об ошибке при назначении автора комментария.
        """
        return (
            "Убедитесь, что поле «автор» формы заполняется"
            " аутентифицированным пользователем."
        )

    @property
    def display_text_error_message(self) -> str:
        """
        Сообщение об ошибке отображения текста созданного комментария.
        """
        return (
            "Убедитесь, что текст созданного комментария отображается"
            " на странице поста."
        )

    def validation_error_message(self, student_form_fields_str: str) -> str:
        """
        Сообщение об ошибке валидации формы.
        """
        return (
            "Убедитесь, что для валидации формы достаточно заполнить следующие"
            f" поля: {student_form_fields_str}."
        )

    @property
    def item_not_created_assertion_msg(self):
        """
        Сообщение об ошибке, если объект комментария не создан.
        """
        return (
            "Убедитесь, что при отправке формы создания комментария"
            " создаётся только один объект комментария в базе данных."
        )

    @property
    def wrong_author_assertion_msg(self):
        """
        Сообщение об ошибке, если автор комментария назначен неверно.
        """
        return (
            "Убедитесь, что поле «автор» заполняется"
            " аутентифицированным пользователем."
        )

    def creation_assertion_msg(self, prop):
        """
        Сообщение об ошибке отображения свойства комментария.
        """
        return (
            "Убедитесь, что после создания комментария значение поля `{prop}`"
            " отображается на странице поста."
        )
