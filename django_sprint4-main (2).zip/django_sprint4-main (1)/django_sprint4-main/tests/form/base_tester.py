# Базовый тестер для взаимодействия с моделями Django

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Type, Optional, Union

from django.db.models import Model
from django.test import Client

from conftest import TitledUrlRepr
from fixtures.types import ModelAdapterT


class BaseTester(ABC):
    """
    Базовый класс для тестирования действий пользователей
    (аутентифицированных, других пользователей, неаутентифицированных)
    при взаимодействии с моделью Django.

    Этот класс задает базовые методы для проверки редиректов и статусов
    ответов при различных действиях.
    """

    @abstractmethod
    def redirect_error_message(
            self, by_user: str, redirect_to_page: Union[TitledUrlRepr, str]
    ):
        """
        Абстрактный метод для формирования сообщения об ошибке
        при некорректном редиректе.

        :param by_user: Кто выполняет действие (например, "пользователь").
        :param redirect_to_page: Ожидаемая страница редиректа.
        """
        raise NotImplementedError

    @abstractmethod
    def status_error_message(self, by_user: str) -> str:
        """
        Абстрактный метод для формирования сообщения об ошибке
        при некорректном статусе ответа.

        :param by_user: Кто выполняет действие (например, "пользователь").
        :return: Сообщение об ошибке.
        """
        raise NotImplementedError

    def __init__(
            self,
            model_cls: Type[Model],
            user_client: Client,
            another_user_client: Optional[Client] = None,
            unlogged_client: Optional[Client] = None,
            item_adapter: ModelAdapterT = None,
    ):
        """
        Инициализация базового тестера.

        :param model_cls: Django-модель, с которой связаны тестируемые действия.
        :param user_client: Клиент, представляющий аутентифицированного пользователя.
        :param another_user_client: Клиент, представляющий другого пользователя (не владельца ресурса).
        :param unlogged_client: Клиент для неаутентифицированного пользователя.
        :param item_adapter: Адаптер для взаимодействия с объектом модели.
        """
        self.user_client = user_client
        self.another_user_client = another_user_client
        self.unlogged_client = unlogged_client
        if item_adapter:
            assert model_cls is item_adapter.item_cls, (
                "Класс модели из адаптера должен совпадать с переданным классом модели."
            )
        self._model_cls = model_cls
        self._item_adapter = item_adapter
