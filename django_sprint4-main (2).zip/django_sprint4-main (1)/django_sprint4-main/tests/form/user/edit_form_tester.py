"""
Модуль для тестирования редактирования профилей пользователей.

На что обратить внимание:
- Форма редактирования профиля должна передаваться на соответствующую страницу.
- Валидация и обработка формы должны учитывать возможность редактирования только для авторизованного пользователя.
- Все тесты соответствуют требованиям к редактированию профилей, включая проверку прав доступа и редиректов.
"""
from typing import Tuple, Union

import bs4
from django.db.models import QuerySet, Model
from django.forms import BaseForm
from django.http import HttpResponse

from conftest import TitledUrlRepr
from fixtures.types import ModelAdapterT
from form.base_form_tester import (
    FormTagMissingException,
    FormMethodException,
    TextareaMismatchException,
    TextareaTagMissingException,
)
from form.base_form_tester import (
    SubmitTester,
    FormValidationException,
    BaseFormTester,
    UnauthorizedEditException,
    UnauthenticatedEditException,
    AuthenticatedEditException,
    DatabaseCreationException,
    ItemCreatedException,
)


class EditUserFormTester(BaseFormTester):
    """
    Класс для тестирования формы редактирования профиля пользователя.

    Обеспечивает проверку наличия формы, прав доступа и корректности
    выполнения редиректов.
    """

    def __init__(
        self,
        response: HttpResponse,
        *args,
        ModelAdapter: ModelAdapterT,
        **kwargs,
    ):
        try:
            super().__init__(
                response, *args, ModelAdapter=ModelAdapter, **kwargs
            )
        except FormTagMissingException as e:
            raise AssertionError(
                "Убедитесь, что на страницу редактирования профиля"
                " пользователя передаётся форма."
            ) from e

    @property
    def has_textarea(self):
        """Форма редактирования профиля пользователя не должна содержать textarea."""
        return False

    @property
    def textarea_tag(self) -> bs4.Tag:
        """Проверка на наличие textarea не применяется для профиля."""
        raise NotImplementedError(
            "Для профиля пользователя поле textarea не предусмотрено."
        )

    def _validate(self):
        """Проверяет основные аспекты валидности формы редактирования."""
        try:
            super()._validate()
        except FormTagMissingException as e:
            raise AssertionError(
                "Убедитесь, что на страницу редактирования профиля"
                " пользователя передаётся форма."
            ) from e
        except FormMethodException as e:
            raise AssertionError(
                "Убедитесь, что форма редактирования профиля пользователя"
                " отправляется методом `POST`."
            ) from e

    # Остальные методы аналогичны предыдущей версии, с пояснительными
    # комментариями и форматированием, если требуется.

        except TextareaMismatchException:
            pass

    """
    Методы тестирования редактирования профилей пользователей.

    На что обратить внимание:
    - Проверка обработки форм редактирования профиля с учётом прав доступа пользователя.
    - Исключение ошибок при работе с формами, таких как неверные данные или несанкционированный доступ.
    - Корректное поведение системы при редактировании профилей, включая переадресацию и отображение изменений.
    """

    def try_create_item(
            self,
            form: BaseForm,
            qs: QuerySet,
            submitter: SubmitTester,
            assert_created: bool = True,
    ) -> Tuple[HttpResponse, Model]:
        """
        Тестирует возможность создания или изменения профиля пользователя
        через отправку формы. Проверяет, что при корректных данных объект
        обновляется корректно.
        """
        try:
            return super().try_create_item(form, qs, submitter, assert_created)
        except FormValidationException as e:
            raise AssertionError(
                "При редактировании профиля пользователя возникает ошибка:\n"
                f"{type(e).__name__}: {e}"
            ) from e

    def test_unlogged_cannot_create(
            self, form: BaseForm, qs: QuerySet
    ) -> None:
        """
        Проверяет, что неаутентифицированный пользователь не может
        создать или изменить профиль через форму.
        """
        try:
            super().test_unlogged_cannot_create(form, qs)
        except ItemCreatedException as e:
            raise AssertionError(
                "Проверьте, что если неаутентифицированный пользователь"
                " отправит форму редактирования профиля - объект пользователя"
                " в базе данных не будет создан или изменён."
            ) from e

    def test_edit_item(
            self, updated_form: BaseForm, qs: QuerySet, item_adapter: ModelAdapterT
    ) -> HttpResponse:
        """
        Тестирует редактирование профиля авторизованным пользователем.
        Проверяет недопустимость редактирования чужих профилей.
        """
        try:
            return super().test_edit_item(updated_form, qs, item_adapter)
        except UnauthorizedEditException:
            raise AssertionError(
                "Убедитесь, что пользователь не может редактировать чужой"
                " профиль пользователя."
            )
        except UnauthenticatedEditException:
            raise AssertionError(
                "Убедитесь, что неаутентифицированный пользователь не может"
                " редактировать профиль пользователя."
            )
        except AuthenticatedEditException:
            raise AssertionError(
                "Убедитесь, что пользователь может редактировать свой"
                " профиль."
            )
        except DatabaseCreationException:
            raise AssertionError(
                "Убедитесь, что при редактировании профиля пользователя в"
                " базе данных не создаётся новый объект профиля пользователя."
            )

    def redirect_error_message(
            self, by_user: str, redirect_to_page: Union[TitledUrlRepr, str]
    ) -> str:
        """
        Генерирует сообщение об ошибке при некорректной переадресации
        после отправки формы редактирования профиля.
        """
        redirect_to_page_repr = self.get_redirect_to_page_repr(
            redirect_to_page
        )
        return (
            "Убедитесь, что после отправки формы редактирования профиля"
            f" пользователя {by_user} он перенаправляется на"
            f" {redirect_to_page_repr}."
        )

    def status_error_message(self, by_user: str) -> str:
        """
        Генерирует сообщение об ошибке при некорректном статусе ответа
        после отправки формы.
        """
        return (
            "Убедитесь, что при отправке формы редактирования профиля"
            f" пользователя {by_user} не возникает ошибок."
        )

    @property
    def author_assignment_error_message(self) -> str:
        """
        Проверяет, что в поле «автор» передаётся аутентифицированный пользователь.
        """
        return (
            "Убедитесь, что в форму редактирования профиля пользователя в поле"
            " «автор» передаётся аутентифицированный пользователь."
        )

    @property
    def display_text_error_message(self) -> str:
        """
        Проверяет, что новый текст отображается на странице профиля после редактирования.
        """
        return (
            "Убедитесь, что после редактировании профиля пользователя новый"
            " текст отображается на странице профиля."
        )

    def validation_error_message(self, student_form_fields_str: str) -> str:
        """
        Сообщение об ошибке валидации формы, если поля формы некорректны
        или их недостаточно для успешной валидации.
        """
        return (
            "Убедитесь, что для валидации формы редактирования профиля"
            " пользователя достаточно заполнить следующие поля:"
            f" {student_form_fields_str}."
        )

    @property
    def item_not_created_assertion_msg(self):
        """
        Проверяет, что при редактировании профиля новый объект в базе данных не создаётся.
        """
        return (
            "Убедитесь, что при отправке формы редактирования профиля"
            " пользователя авторизованным пользователем в базе данных не"
            " создаётся новый профиль пользователя."
        )

    @property
    def wrong_author_assertion_msg(self):
        """
        Генерирует исключение для некорректного вызова теста на создание профиля.
        """
        raise NotImplementedError(
            "User profiles are not supposed to be created from code."
        )

    def creation_assertion_msg(self, prop):
        """
        Генерирует сообщение об ошибке при некорректной переадресации
        после успешного редактирования профиля.
        """
        return (
            "Убедитесь, что после отправки формы редактировании профиля"
            " пользователя правильно работает  переадресация. Проверьте, что"
            f" значение поля `{prop}` отображается на странице профиля."
        )

