"""
Базовый класс тестирования форм в Django.

Особенности:
- Проверяет наличие формы на странице.
- Поддерживает адаптацию полей формы через `ModelAdapter`.
- Реализует тестирование корректности методов отправки данных (GET, POST).
- Генерирует детализированные сообщения об ошибках для упрощения отладки.

Ключевые моменты:
- Проверка работы форм редактирования, создания и удаления объектов.
- Гибкая настройка валидации с поддержкой кастомных ошибок.
- Реализация абстрактных методов для уточнения логики в дочерних классах.

На что обратить внимание:
- Наличие проверок на корректность используемых методов отправки форм (например, метод `POST`).
- Адаптация формы через `ModelAdapter`, что позволяет абстрагироваться от структуры модели.
"""

from __future__ import annotations

# Импорт необходимых модулей и библиотек для реализации тестирования
import re  # Работа с регулярными выражениями для анализа строк
from abc import abstractmethod, ABC  # Реализация абстрактных классов
from functools import partial  # Функция для создания частичных функций
from http import HTTPStatus  # Константы HTTP-статусов
from typing import (  # Типизация данных
    Set,
    Tuple,
    Type,
    Sequence,
    Callable,
    Optional,
    Dict,
    Iterable,
    Any,
    List,
    Union,
)

import bs4  # Библиотека BeautifulSoup для обработки HTML
import django.test  # Тестовые утилиты Django
from django.core.files.uploadedfile import SimpleUploadedFile  # Загрузка файлов
from django.db.models import Model, QuerySet  # Работа с моделями Django
from django.forms import BaseForm  # Базовый класс для форм Django
from django.http import HttpResponse  # Класс ответа HTTP

# Импорт пользовательских утилит и типов
from conftest import (
    ItemNotCreatedException,  # Исключение, если объект не был создан
    restore_cleaned_data,  # Функция для восстановления данных формы
    TitledUrlRepr,  # Тип данных для представления URL
)
from fixtures.types import ModelAdapterT  # Тип адаптера для модели
from form.base_tester import BaseTester  # Базовый класс тестера

# Определение пользовательских исключений для обработки ошибок в формах
class FormValidationException(Exception):
    """Общее исключение для ошибок валидации формы."""
    pass


class FormTagMissingException(FormValidationException):
    """Исключение: отсутствует тег <form> в HTML."""
    pass


class FormMethodException(FormValidationException):
    """Исключение: форма отправляется методом, отличным от POST."""
    pass


class TextareaMismatchException(FormValidationException):
    """Исключение: содержимое поля <textarea> не соответствует ожиданиям."""
    pass


class ItemCreatedException(Exception):
    """Исключение: объект был создан, хотя этого не ожидалось."""
    pass


class UnauthorizedEditException(Exception):
    """Исключение: неавторизованный пользователь попытался редактировать."""
    pass


class UnauthenticatedEditException(Exception):
    """Исключение: неаутентифицированный пользователь попытался редактировать."""
    pass


class AuthenticatedEditException(Exception):
    """Исключение: аутентифицированный пользователь не смог редактировать."""
    pass


class DatabaseCreationException(Exception):
    """Исключение: при редактировании был создан новый объект в базе данных."""
    pass


class TextareaTagMissingException(Exception):
    """Исключение: отсутствует тег <textarea> в HTML."""
    pass

# Класс для тестирования форм на страницах
class BaseFormTester(BaseTester):
    """
    Класс для тестирования HTML-форм, представленных в ответах HTTP.

    Используется для проверки корректности структуры и поведения форм,
    включая их валидацию, метод отправки и обработку ошибок.
    """
    def __init__(
        self,
        response: HttpResponse,  # HTTP-ответ
        *args,
        ModelAdapter: ModelAdapterT,  # Адаптер для работы с моделью
        **kwargs,
    ):
        super().__init__(*args, **kwargs)

        # Парсинг HTML-ответа для извлечения формы
        soup = bs4.BeautifulSoup(response.content, features="html.parser")
        form_tag = soup.find("form")
        if not form_tag:
            raise FormTagMissingException()  # Ошибка, если форма отсутствует

        self._form_tag = form_tag  # Сохранение тега формы
        self._action = self._form_tag.get("action", "") or (
            response.request["PATH_INFO"]  # Определение URL для отправки
        )
        self._ModelAdapter = ModelAdapter  # Сохранение адаптера модели

        self._validate()  # Проверка формы на соответствие ожиданиям

    @property
    @abstractmethod
    def has_textarea(self):
        """Определяет, содержит ли форма элемент <textarea>."""
        ...

    @property
    def unauthorized_edit_redirect_cbk(self):
        """Колбэк для обработки редиректа при редактировании без авторизации."""
        return None

    @property
    def anonymous_edit_redirect_cbk(self):
        """Колбэк для обработки редиректа при редактировании анонимным пользователем."""
        return None

    @abstractmethod
    def redirect_error_message(
        self, by_user: str, redirect_to_page: Union[TitledUrlRepr, str]
    ) -> str:
        """
        Возвращает сообщение об ошибке, если редирект после отправки формы был выполнен неверно.

        :param by_user: Описание инициатора редиректа (например, "пользователь").
        :param redirect_to_page: URL или объект `TitledUrlRepr`, представляющий целевую страницу.
        :return: Строка с сообщением об ошибке.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def author_assignment_error_message(self) -> str:
        """
        Возвращает сообщение об ошибке, если автор объекта был назначен неверно при создании или редактировании.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def display_text_error_message(self) -> str:
        """
        Возвращает сообщение об ошибке, если текст созданного или отредактированного объекта
        не отображается на соответствующей странице.
        """
        raise NotImplementedError

    @abstractmethod
    def validation_error_message(self, student_form_fields_str: str) -> str:
        """
        Возвращает сообщение об ошибке, если валидация формы не прошла из-за неправильных данных.

        :param student_form_fields_str: Список названий полей формы, требующих проверки.
        :return: Строка с сообщением об ошибке.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def item_not_created_assertion_msg(self):
        """
        Возвращает сообщение об ошибке, если объект не был создан в базе данных после отправки формы.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def wrong_author_assertion_msg(self):
        """
        Возвращает сообщение об ошибке, если автор объекта был назначен неправильно.
        """
        raise NotImplementedError

    def get_redirect_to_page_repr(self, redirect_to_page) -> str:
        """
        Возвращает строковое представление целевой страницы редиректа.

        :param redirect_to_page: Может быть строкой (URL) или объектом `TitledUrlRepr`.
        :return: Строка, представляющая целевую страницу редиректа.
        """
        if isinstance(redirect_to_page, str):
            redirect_to_page_repr = redirect_to_page
        elif isinstance(redirect_to_page, tuple):  # ожидаемый формат TitledUrlRepr
            (
                redirect_pattern,
                redirect_repr,
            ), redirect_title = redirect_to_page
            redirect_to_page_repr = f"{redirect_title} ({redirect_repr})"
        else:
            raise AssertionError(
                f"Неверный тип значения `{type(redirect_to_page)}` "
                "для `redirect_to_page`."
            )
        return redirect_to_page_repr

    @abstractmethod
    def status_error_message(self, by_user: str) -> str:
        """
        Абстрактный метод. Возвращает сообщение об ошибке статуса ответа.

        :param by_user: Строка, описывающая инициатора действия (например, "пользователь").
        :return: Сообщение об ошибке в случае неверного HTTP-статуса.
        """
        raise NotImplementedError

    @property
    def textarea_tag(self) -> bs4.Tag:
        """
        Возвращает HTML-тег `textarea`, если он присутствует в форме.

        :return: Объект `bs4.Tag`, представляющий поле `textarea`.
        :raises TextareaTagMissingException: Если поле `textarea` отсутствует.
        """
        textarea = self._form_tag.find("textarea")
        if not textarea:
            raise TextareaTagMissingException()
        return textarea

    def _validate(self):
        """
        Выполняет валидацию формы на наличие тега, метода POST и корректного значения поля `textarea`.

        :raises FormTagMissingException: Если форма отсутствует.
        :raises FormMethodException: Если метод отправки формы не `POST`.
        :raises TextareaMismatchException: Если текст в поле `textarea` не совпадает с ожидаемым.
        """
        if not self._form_tag:
            raise FormTagMissingException()

        if self._form_tag.get("method", "get").upper() != "POST":
            raise FormMethodException()

        if self.has_textarea and self._item_adapter:
            textarea = self.textarea_tag
            if textarea.text.strip() != self._item_adapter.text.strip():
                raise TextareaMismatchException()

    def try_create_item(
            self,
            form: BaseForm,
            qs: QuerySet,
            submitter: SubmitTester,
            assert_created: bool = True,
    ) -> Tuple[HttpResponse, Model]:
        """
        Пытается создать объект модели на основе переданной формы.

        :param form: Форма для создания объекта.
        :param qs: QuerySet для получения всех объектов соответствующей модели.
        :param submitter: Экземпляр SubmitTester для отправки данных.
        :param assert_created: Указывает, ожидать ли успешного создания объекта.
        :return: Ответ сервера и созданный объект (если создан).
        :raises FormValidationException: Если форма невалидна.
        :raises ItemNotCreatedException: Если объект не был создан, но ожидалось его создание.
        :raises ItemCreatedException: Если объект был создан, но не ожидалось его создание.
        """
        if not form.is_valid():
            raise FormValidationException(form.errors)
        elif form.errors:
            raise FormValidationException(form.errors)

        # Получение списка объектов до создания нового
        items_before = set(qs.all())

        # Восстановление данных формы
        restored_data = restore_cleaned_data(form.cleaned_data)
        try:
            response = submitter.test_submit(
                url=self._action, data=restored_data
            )
        except Exception as e:
            raise FormValidationException(e) from e

        # Получение списка объектов после попытки создания нового
        items_after: Set[Model] = set(qs.all())
        created_items = items_after - items_before
        n_created = len(created_items)
        created = next(iter(created_items)) if created_items else None

        if assert_created:
            # Если объект должен был быть создан, но его нет
            if not n_created:
                raise ItemNotCreatedException()
        elif n_created:
            # Если объект был создан, но его создание не ожидалось
            raise ItemCreatedException()

        return response, created

    @staticmethod
    def init_create_item_form(Form: Type[BaseForm], **form_data) -> BaseForm:
        """
        Инициализирует форму для создания объекта.

        :param Form: Класс формы.
        :param form_data: Данные, которые нужно передать в форму.
        :return: Экземпляр формы.
        """
        return Form(data=form_data)

    def init_create_item_forms(
            self,
            Form: Type[BaseForm],
            Model: Type[Model],
            ModelAdapter: ModelAdapterT,
            forms_unadapted_data: Iterable[Dict[str, Any]],
    ) -> List[BaseForm]:
        """
        Инициализирует список форм для создания нескольких объектов.

        :param Form: Класс формы.
        :param Model: Класс модели.
        :param ModelAdapter: Адаптер для работы с моделью.
        :param forms_unadapted_data: Данные, которые нужно адаптировать для заполнения форм.
        :return: Список экземпляров формы.
        """
        creation_forms = []

        model_adapter = ModelAdapter(Model)
        for unadapted_form_data in forms_unadapted_data:
            adapted_form_data = {}
            for k, v in unadapted_form_data.items():
                adapted_form_data[getattr(model_adapter, k).field.name] = v
            creation_forms.append(
                self.init_create_item_form(Form, **adapted_form_data)
            )

        return creation_forms

    def test_unlogged_cannot_create(
            self, form: BaseForm, qs: QuerySet
    ) -> None:
        """
        Проверяет, что неаутентифицированный пользователь не может создать объект.

        :param form: Форма для создания объекта.
        :param qs: QuerySet модели.
        """
        self.test_create_item(
            form,
            qs,
            AnonymousSubmitTester(self, test_response_cbk=None),
            assert_created=False,
        )

    def test_create_item(
            self,
            form: BaseForm,
            qs: QuerySet,
            submitter: SubmitTester,
            assert_created: bool = True,
    ) -> Tuple[HttpResponse, Model]:
        """
        Проверяет создание объекта на основе формы.

        :param form: Форма для создания объекта.
        :param qs: QuerySet модели.
        :param submitter: Инструмент отправки запроса.
        :param assert_created: Ожидание создания объекта.
        :return: Ответ сервера и созданный объект.
        :raises AssertionError: Если результат теста не соответствует ожиданиям.
        """
        try:
            response, created = self.try_create_item(
                form, qs, submitter, assert_created
            )
        except FormValidationException:
            student_form_fields = [
                self._ModelAdapter(form.Meta.model).get_student_field_name(k)
                for k in form.data.keys()
            ]
            student_form_fields_str = ", ".join(student_form_fields)
            raise AssertionError(
                self.validation_error_message(student_form_fields_str)
            )
        if assert_created:
            assert (
                    self._ModelAdapter(created).author
                    == response.wsgi_request.user
            ), self.author_assignment_error_message
            content = response.content.decode(encoding="utf8")
            if self._ModelAdapter(created).text in content:
                if not assert_created:
                    raise AssertionError(self.display_text_error_message)

        return response, created

    def test_create_several(
            self, forms: Iterable[BaseForm], qs: QuerySet
    ) -> Tuple[HttpResponse, List[Model]]:
        """
        Проверяет создание нескольких объектов.

        :param forms: Список форм для создания объектов.
        :param qs: QuerySet модели.
        :return: Ответ сервера и список созданных объектов.
        :raises AssertionError: Если создание объектов не удалось.
        """
        created_items = []
        for form in forms:
            try:
                response, created = self.test_create_item(
                    form,
                    qs,
                    AuthorisedSubmitTester(
                        self,
                        test_response_cbk=(
                            AuthorisedSubmitTester.get_test_response_ok_cbk(
                                tester=self
                            )
                        ),
                    ),
                    assert_created=True,
                )
            except ItemNotCreatedException:
                raise AssertionError(self.item_not_created_assertion_msg)

            created_items.append(created)
            assert (
                    self._ModelAdapter(created).author
                    == response.wsgi_request.user
            ), self.wrong_author_assertion_msg

        # noinspection PyUnboundLocalVariable
        return response, created_items

    @staticmethod
    def init_create_form_from_item(
            item: Model,
            Form: Type[BaseForm],
            ModelAdapter: ModelAdapterT,
            file_data: Optional[Dict[str, SimpleUploadedFile]],
            **update_form_data,
    ) -> BaseForm:
        """
        Создает экземпляр формы на основе объекта модели и дополнительных данных.

        Аргументы:
            item: Экземпляр модели, для которого создается форма.
            Form: Класс формы.
            ModelAdapter: Адаптер для модели, предоставляющий доступ к полям.
            file_data: Дополнительные данные для файлов.
            **update_form_data: Данные для обновления формы.
        """
        form = Form(instance=item)
        form_data = form.initial

        # Обновляем данные формы с использованием переданных значений
        model_adapter = ModelAdapter(item.__class__)
        for k, v in update_form_data.items():
            form_data.update({getattr(model_adapter, k).field.name: v})

        # Заменяем связанные объекты их идентификаторами для валидации
        form_data = {
            k: v.id if isinstance(v, Model) else v
            for k, v in form_data.items()
        }

        # Удаляем данные файлов, если они указаны
        if file_data:
            for k in file_data:
                del form_data[k]

        result = Form(data=form_data, files=file_data)
        return result

    @abstractmethod
    def creation_assertion_msg(self, prop):
        """
        Возвращает сообщение для утверждения создания объекта.

        Аргумент:
            prop: Свойство объекта для проверки.
        """
        pass

    def test_creation_response(
            self, content: str, created_items: Iterable[Model]
    ):
        """
        Проверяет отображение созданных объектов в контенте ответа.

        Аргументы:
            content: HTML-контент ответа.
            created_items: Созданные объекты.
        """
        for item in created_items:
            item_adapter = self._ModelAdapter(item)
            prop = item_adapter.item_cls_adapter.displayed_field_name_or_value
            if not self._ModelAdapter(item).text in content:
                raise AssertionError(
                    self.creation_assertion_msg(
                        item_adapter.get_student_field_name(prop)
                    )
                )

    def test_edit_item(
            self, updated_form: BaseForm, qs: QuerySet, item_adapter: ModelAdapterT
    ) -> HttpResponse:
        """
        Проверяет возможность редактирования объекта текущим пользователем.

        Аргументы:
            updated_form: Обновленная форма для редактирования объекта.
            qs: QuerySet для выборки объектов.
            item_adapter: Адаптер объекта модели.

        Возвращает:
            HttpResponse: Ответ после отправки формы.
        """
        instances_before: Set[Model] = set(qs.all())

        # Проверка прав редактирования другим пользователем
        can_edit, _ = self.user_can_edit(
            self.another_user_client,
            submitter=UnauthorizedSubmitTester(
                tester=self,
                test_response_cbk=self.unauthorized_edit_redirect_cbk,
            ),
            item_adapter=item_adapter,
            updated_form=updated_form,
        )

        if can_edit:
            raise UnauthorizedEditException()

        # Проверка прав редактирования неаутентифицированным пользователем
        can_edit, _ = self.user_can_edit(
            self.unlogged_client,
            submitter=AnonymousSubmitTester(
                tester=self, test_response_cbk=self.anonymous_edit_redirect_cbk
            ),
            item_adapter=item_adapter,
            updated_form=updated_form,
        )

        if can_edit:
            raise UnauthenticatedEditException()

        # Проверка редактирования текущим пользователем
        can_edit, response = self.user_can_edit(
            self.user_client,
            submitter=AuthorisedSubmitTester(
                tester=self,
                test_response_cbk=(
                    AuthorisedSubmitTester.get_test_response_ok_cbk(
                        tester=self
                    )
                ),
            ),
            item_adapter=item_adapter,
            updated_form=updated_form,
        )

        if not can_edit:
            raise AuthenticatedEditException()

        instances_after: Set[Model] = set(qs.all())

        # Проверка отсутствия новых объектов в базе после редактирования
        created_instances_n = instances_after - instances_before

        if len(created_instances_n) != 0:
            raise DatabaseCreationException()

        return response

    def user_can_edit(
            self, client, submitter: SubmitTester, item_adapter, updated_form
    ) -> Tuple[Optional[bool], Optional[HttpResponse]]:
        """
        Проверяет, может ли указанный клиент редактировать объект.

        Аргументы:
            client: Клиент для выполнения запроса.
            submitter: Экземпляр SubmitTester для отправки запроса.
            item_adapter: Адаптер объекта модели.
            updated_form: Обновленная форма.

        Возвращает:
            Tuple[Optional[bool], Optional[HttpResponse]]: Флаг успеха и ответ.
        """
        if not client:
            return None, None
        disp_old_value = item_adapter.displayed_field_name_or_value
        response = submitter.test_submit(
            url=self._action, data=updated_form.data
        )
        item_adapter.refresh_from_db()
        disp_new_value = item_adapter.displayed_field_name_or_value
        return disp_new_value != disp_old_value, response


class SubmitTester(ABC):
    __slots__ = ["expected_codes", "client", "_test_response_cbk", "_tester"]

    def __init__(
        self,
        tester: BaseTester,
        test_response_cbk: Optional[Callable[[HttpResponse], None]],
    ):
        # Инициализация объекта тестера с настройкой обработчика ответа.
        self._tester = tester
        self._test_response_cbk = test_response_cbk

    def test_submit(self, url: str, data: dict) -> HttpResponse:
        # Отправка POST-запроса с тестовыми данными.
        assert isinstance(self.client, django.test.Client)
        response = self.client.post(url, data=data, follow=True)
        if self._test_response_cbk:
            self._test_response_cbk(response)  # Проверка ответа через callback.
        return response

    @staticmethod
    def test_response_cbk(
        response: HttpResponse,
        err_msg: str,
        assert_status_in: Sequence[int] = tuple(),
        assert_status_not_in: Sequence[int] = tuple(),
        assert_redirect: Optional[Union[TitledUrlRepr, bool]] = None,
    ):
        # Проверка корректности статуса ответа и выполнения редиректа.
        if assert_status_in and response.status_code not in assert_status_in:
            raise AssertionError(err_msg)
        if assert_status_not_in and (
            response.status_code in assert_status_not_in
        ):
            raise AssertionError(err_msg)
        if assert_redirect is not None and assert_redirect:
            assert hasattr(response, "redirect_chain") and getattr(
                response, "redirect_chain"
            ), err_msg
            if isinstance(assert_redirect, tuple):  # Проверка соответствия URL.
                (
                    redirect_pattern,
                    redirect_repr,
                ), redirect_title = assert_redirect
                redirect_match = False
                for redirect_url, _ in response.redirect_chain:
                    if re.match(redirect_pattern, redirect_url):
                        redirect_match = True
                        break
                assert redirect_match, err_msg

    @staticmethod
    def get_test_response_redirect_cbk(
        tester: BaseTester,
        redirect_to_page: Union[TitledUrlRepr, str],
        by_user: Optional[str] = None,
    ):
        # Создание callback для проверки редиректа при отправке формы.
        by_user = by_user or "пользователь"
        return partial(
            SubmitTester.test_response_cbk,
            assert_status_in=(HTTPStatus.OK,),
            assert_redirect=redirect_to_page,
            err_msg=tester.redirect_error_message(by_user, redirect_to_page),
        )

    @staticmethod
    def get_test_response_ok_cbk(
        tester: BaseTester, by_user: Optional[str] = None
    ):
        # Callback для проверки успешного выполнения запроса.
        by_user = by_user or "авторизованным пользователем"
        return partial(
            SubmitTester.test_response_cbk,
            assert_status_in=(HTTPStatus.OK,),
            err_msg=tester.status_error_message(by_user),
        )

    @staticmethod
    def get_test_response_404_cbk(err_msg: str):
        # Callback для проверки возврата ошибки 404.
        return partial(
            SubmitTester.test_response_cbk,
            assert_status_in=(HTTPStatus.NOT_FOUND,),
            err_msg=err_msg,
        )


class AuthorisedSubmitTester(SubmitTester):
    def __init__(
        self,
        tester: BaseTester,
        test_response_cbk: Optional[Callable[[HttpResponse], None]],
    ):
        super().__init__(tester, test_response_cbk=test_response_cbk)
        # Установка клиента для авторизованного пользователя.
        self.client = tester.user_client

    @staticmethod
    def get_test_response_redirect_cbk(
        tester: BaseTester,
        by_user: Optional[str] = None,
        redirect_to_page: Optional[str] = None,
    ):
        # Callback для проверки редиректа для авторизованного пользователя.
        return SubmitTester.get_test_response_redirect_cbk(
            tester=tester,
            by_user=by_user or "авторизованным пользователем",
            redirect_to_page=redirect_to_page,
        )

    class UnauthorizedSubmitTester(SubmitTester):
        def __init__(
                self,
                tester: BaseTester,
                test_response_cbk: Optional[Callable[[HttpResponse], None]],
        ):
            super().__init__(tester, test_response_cbk=test_response_cbk)
            # Устанавливаем клиент для другого авторизованного пользователя
            # (не является владельцем ресурса).
            self.client = tester.another_user_client

        @staticmethod
        def get_test_response_redirect_cbk(
                tester: BaseTester,
                redirect_to_page: Union[TitledUrlRepr, str],
                by_user: Optional[str] = None,
        ):
            # Настройка проверки редиректа для пользователей,
            # не имеющих прав доступа к ресурсу.
            return SubmitTester.get_test_response_redirect_cbk(
                tester=tester,
                by_user=by_user or "неавторизованным пользователем",
                redirect_to_page=redirect_to_page,
            )

    class AnonymousSubmitTester(SubmitTester):
        def __init__(
                self,
                tester: BaseTester,
                test_response_cbk: Optional[Callable[[HttpResponse], None]],
        ):
            super().__init__(tester, test_response_cbk=test_response_cbk)
            # Устанавливаем клиента для неаутентифицированного пользователя.
            self.client = tester.unlogged_client

        @staticmethod
        def get_test_response_redirect_cbk(
                tester: BaseTester,
                redirect_to_page: Optional[str] = None,
                by_user: Optional[str] = None,
        ):
            # Настройка проверки редиректа для неаутентифицированного пользователя.
            return SubmitTester.get_test_response_redirect_cbk(
                tester=tester,
                by_user=by_user or "неаутентифицированным пользователем",
                redirect_to_page=redirect_to_page or "страницу аутентификации",
            )
