"""
Файл маршрутов (urls.py) для проекта Blogicum.

- Обеспечивает маршрутизацию для всех страниц проекта, включая обработку ошибок.
- Реализована поддержка регистрации пользователей с использованием встроенной формы `UserCreationForm`.
- Включены маршруты для приложений `pages`, `blog`, а также встроенные маршруты для аутентификации Django.
- Отладочная панель доступна при включенном режиме DEBUG, а также настроены пути к медиафайлам.
"""

from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth.forms import UserCreationForm
from django.urls import include, path, reverse_lazy
from django.views.generic.edit import CreateView

from blogicum import settings

# Обработчики ошибок
handler404 = 'pages.views.page_not_found'
handler500 = 'pages.views.server_error'

urlpatterns = [
    # Маршруты приложения pages
    path('pages/', include('pages.urls', namespace='pages')),

    # Маршруты для встроенных аутентификационных представлений Django
    path('auth/', include('django.contrib.auth.urls')),

    # Маршрут для регистрации пользователей
    path('auth/registration/', CreateView.as_view(
        template_name='registration/registration_form.html',
        form_class=UserCreationForm,
        success_url=reverse_lazy('blog:index')
    ), name='registration'),

    # Панель администратора
    path('admin/', admin.site.urls),

    # Основное приложение проекта blog
    path('', include('blog.urls', namespace='blog')),
]

# Отладочные маршруты и статические файлы
if settings.DEBUG:
    urlpatterns += [
        path("__debug__/", include("debug_toolbar.urls")),
    ]
    urlpatterns += static(
        settings.MEDIA_URL, document_root=settings.MEDIA_ROOT
    )
